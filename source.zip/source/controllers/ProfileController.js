const User = require('../models/user')
const cloudinary = require('../utils/cloudinary.js')
const bcrypt = require("bcrypt")

class ProfileController {
    async get(req, res) {
        if (!req.session.login) {
            return res.redirect('/login');
        }
        else {
            const username = req.session.username
            const user = await User.get('username', username)
            const { fullname, email, phone, birthday, address, frontIC, backIC, activate } = user.userData
            return res.json({ fullname, email, phone, birthday, address, frontIC, backIC, activate })
        }
    }

    getChangepass(req, res) {
        if (!req.session.login) {
            return res.redirect('/login');
        }
        res.render('changepass', { title: 'ChangePassword' });
    }

    async postChangepass(req, res) {
        const username = req.session.username;

        var curpassword = req.body.curpassword;
        var password = req.body.password;
        var cfmpassword = req.body.cfmpassword;

        if (curpassword == '') {
            return res.render('changepass', { err: true, curpassword, password, cfmpassword, msg: 'Please enter current password', title: 'ChangePassword' });
        }

        if (password == '') {
            return res.render('changepass', { err: true, curpassword, password, cfmpassword, msg: 'Please enter new password', title: 'ChangePassword' });
        }

        if (cfmpassword == '') {
            return res.render('changepass', { err: true, curpassword, password, cfmpassword, msg: 'Please enter confirm password', title: 'ChangePassword' });
        }

        else {
            const currentUser = await User.get('username', username)

            if (!await bcrypt.compare(curpassword, currentUser.userData.password)) {
                return res.render('changepass', { err: true, curpassword: '', password, cfmpassword, msg: 'Current password is not correct', title: 'ChangePassword' });
            } else if (await bcrypt.compare(password, currentUser.userData.password)) {
                return res.render('changepass', { err: true, curpassword, password: '', cfmpassword: '', msg: 'New password is already in use', title: 'ChangePassword' });
            }

            if (password != cfmpassword) {
                return res.render('changepass', { err: true, curpassword, password, cfmpassword: '', msg: 'Confirm password is not match', title: 'ChangePassword' });
            }

            const hashNewPassword = await bcrypt.hash(password, 11)

            User.update('password', hashNewPassword, 'username', username);
            User.update('checkfirst', 1, 'username', username);

            return res.redirect('/');
        }
    }

    getReupIC(req, res) {
        if (!req.session.login) {
            return res.redirect('/login');
        }
        res.render('reupIC', { title: 'getReupIC' });
    }

    async postReupIC(req, res) {
        if (!req.session.login) {
            return res.redirect('/login');
        }

        const username = req.session.username
        const currentUser = await User.get('username', username)
        let frontIC = null
        let backIC = null

        const uploader = async (path) => await cloudinary.uploads(path, currentUser.userData.email)

        const files = req.files;

        if (files.frontIC) {
            const frontIC_Path = files.frontIC[0].path
            const newFrontIC = await uploader(frontIC_Path)
            frontIC = newFrontIC.url
        }

        if (files.backIC) {
            const backIC_Path = files.backIC[0].path
            const newBackIC = await uploader(backIC_Path)
            backIC = newBackIC.url
        }

        if (frontIC) {
            await User.update('frontIC', frontIC, 'username', username)
        }

        if (backIC) {
            await User.update('backIC', backIC, 'username', username)
        }
        const d = new Date();
        await User.update('activate', '4', 'username', username)
        await User.update('dateUpdate', d.toString(), 'username', username)


        res.redirect('/');
    }
}

module.exports = new ProfileController;