const User = require('../models/user');
const Money = require('../models/money');
const Histories = require('../models/histories');
const Details = require('../models/details');
const randomFunction = require('../libs/randomFunction.js')
const sendMailFunction = require('../libs/sendMail.js')
const bcrypt = require("bcrypt")


class HomeController {
    async index(req, res) {
        if (!req.session.login) {
            return res.redirect('/login');
        }

        if (req.session.changepassfirst) {
            return res.redirect('/changepassfirst');
        }

        if (req.session.login && req.session.username) {
            const username = req.session.username;

            const currentUser = await User.get('username', username)
            const name = currentUser.userData.fullname;
            const activate = currentUser.userData.activate;

            const currentMoney = await Money.get('username', username)
            let balance = currentMoney.userData.balance;
            balance = new Intl.NumberFormat().format(balance) + ' VND';

            let waitingAcc = false
            if (!activate) {
                waitingAcc = true
            }

            let updateAcc = false
            if (activate == 3) {
                updateAcc = true
            }

            let waitingIC = false
            if (activate == 4) {
                waitingIC = true
            }

            let admin = false
            if (req.session.admin) {
                admin = true
            }

            return res.render('index', { activate, title: 'Home', name, balance, username: username, admin, waitingAcc, updateAcc, waitingIC });
        }
    }

    async getChangepassfirst(req, res) {
        if (!req.session.login) {
            return res.redirect('/login');
        }
        else {
            const username = req.session.username;
            const currentUser = await User.get('username', username)

            if (currentUser.userData.checkfirst == 1) {
                req.session.changepassfirst = false
                return res.redirect('/')
            } else {
                req.session.changepassfirst = true
                res.render('changepassfirst', { title: 'ChangePassword' })
            }
        }
    }

    async postChangepassfirst(req, res) {
        const username = req.session.username;

        const newPassword = req.body.password;

        const cfmpassword = req.body.cfmpassword;

        const user = await User.find('username', username)

        if (user.hasError || !user.exist) {
            return res.render('login', { err: true, username, msg: 'User isn\'t existed', title: 'Login' })
        }

        if (await bcrypt.compare(newPassword, user.userData.password)) {
            return res.render('changepassfirst', { err: true, msg: 'This password is already in use', title: 'ChangePassword' });
        }

        if (newPassword != cfmpassword) {
            return res.render('changepassfirst', { err: true, msg: "The confirm password isn't matched", title: 'ChangePassword' });
        }

        const hashNewPassword = await bcrypt.hash(newPassword, 11)

        const isUpdatePasswordSuccess = await User.update('password', hashNewPassword, 'username', username);
        const isUpdateCheckfirstSuccess = await User.update('checkfirst', 1, 'username', username)

        if (isUpdatePasswordSuccess.status == 'success' && isUpdateCheckfirstSuccess.status == 'success') {
            req.session.changepassfirst = false;
            return res.redirect('/');
        } else {
            return res.redirect('/changepassfirst');
        }
    }

    logout(req, res) {
        req.session.username = null;
        req.session.changepassfirst = false;
        req.session.login = false;
        req.session.otp = false
        req.session.admin = false;

        res.redirect('/login');
    }

    getFormresetpass(req, res) {
        if (req.session.login) {
            return res.redirect('/');
        }

        return res.render('formresetpass', { title: 'Form' });
    }

    async postFormresetpass(req, res) {

        if (req.body.sendFor == 'sendagain') {
            const username = req.session.username;
            const { email } = req.body
            //create random otp
            var otp = randomFunction.randomOTP();
            await Money.update('otp', otp, 'username', username);

            // SEND MAIL
            const content = `Your OTP to reset password. Don't send for anyone \n`
                + `    OTP: ` + otp
            await sendMailFunction.sendMail(email, 'OTP info', content)

            var date = new Date();
            var limitaion = date.setMinutes(date.getMinutes() + 1);

            await Money.update('otptime', limitaion, 'username', username);

            const result = {
                message: {
                    type: 'alert-success',
                    content: 'create new otp successfull'
                }
            }
            return res.status(200).json({ result })
        }

        if (req.body.sendFor == 'enterotp') {
            var otp = req.body.otp;
            const username = req.session.username;
            var date = new Date();

            if (otp == '') {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'Please enter OTP'
                    }
                }
                return res.status(400).json({ result })
            }

            const currentMoney = await Money.get('username', username)
            if (currentMoney.userData.otp != otp) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'OTP is not correct'
                    }
                }
                return res.status(400).json({ result })
            }

            if (currentMoney.userData.otptime < date) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'OTP is invalidate, please click \'Send again\' to get new OTP'
                    }
                }
                return res.status(400).json({ result })
            }

            req.session.otp = true
            const result = {
                isSuccess: true,
                message: {
                    type: 'alert-success',
                    content: 'Move to reset password form'
                }
            }
            return res.status(200).json({ result })
        }

        if (req.body.sendFor == 'entersubmit') {

            const { email, phone } = req.body;
            console.log(email, phone)

            if (email == '') {
                const result = {
                    error: true,
                    message: {
                        type: 'alert-warning',
                        content: 'Please enter email'
                    }
                }
                return res.status(400).json({ result })
            }

            if (phone == '') {
                const result = {
                    error: true,
                    message: {
                        type: 'alert-warning',
                        content: 'Please enter phone'
                    }
                }
                return res.status(400).json({ result })
            }

            //check phone exist
            const checkExistPhone = await User.find('phone', phone)
            if (checkExistPhone.hasError || !checkExistPhone.exist) {
                const result = {
                    error: true,
                    message: {
                        type: 'alert-warning',
                        content: 'This email or phone number has not been created yet'
                    }
                }
                return res.status(400).json({ result })
            }
            console.log(checkExistPhone.userData.email)
            if (checkExistPhone.userData.email != email) {
                const result = {
                    error: true,
                    message: {
                        type: 'alert-warning',
                        content: 'This email and phone number is not match'
                    }
                }
                return res.status(400).json({ result })
            }

            const currentUser = await User.get('email', email)

            const username = currentUser.userData.username;
            req.session.username = username;

            var otp = randomFunction.randomOTP();
            await Money.update('otp', otp, 'username', username);

            // SEND MAIL
            const content = `Your OTP to reset password. Don't send for anyone \n`
                + `    OTP: ` + otp
            await sendMailFunction.sendMail(email, 'username and password info', content)

            var date = new Date();
            var limitaion = date.setMinutes(date.getMinutes() + 1);

            await Money.update('otptime', limitaion, 'username', username);

            const result = {
                error: false,
                message: {
                    type: 'alert-success',
                    content: 'waiting enter otp form your email'
                }
            }
            return res.status(400).json({ result })
        }
    }

    getResetpassword(req, res) {
        console.log(req.session.otp)
        if (req.session.login) {
            return res.redirect('/');
        }

        if (!req.session.username) {
            return res.redirect('/login');
        }

        if (!req.session.otp) {
            return res.redirect('/formresetpass');
        }

        return res.render('resetpassword');
    }

    async postResetpassword(req, res) {
        const username = req.session.username;
        var password = req.body.password;
        var cfmpassword = req.body.cfmpassword;

        if (password == '') {
            return res.render('resetpassword', { err: true, password, cfmpassword, msg: 'Please enter new password', title: 'ResetPassword' });
        }

        else if (cfmpassword == '') {
            return res.render('resetpassword', { err: true, password, cfmpassword, msg: 'Please enter confirm password', title: 'ResetPassword' });
        }

        else {
            if (password != cfmpassword) {
                return res.render('resetpassword', { err: true, password, cfmpassword: '', msg: 'Confirm password is not match', title: 'ResetPassword' });
            }
            else {

                const hashNewPassword = await bcrypt.hash(password, 11)

                await User.update('password', hashNewPassword, 'username', username)
                req.session.username = null;
                return res.redirect('/');
            }
        }
    }

    async getAdminaction(req, res) {
        var actionType = req.body.actionType;
        var stt = req.body.stt;

        if (actionType == 'verify') {
            await User.update('activate', 1, 'stt', stt);
            const result = {
                message: {
                    type: 'alert-success',
                    content: 'verify account successfull'
                }
            }
            return res.status(200).json({ result })
        }
        else if (actionType == 'cancel') {
            await User.update('activate', 2, 'stt', stt);
            const result = {
                message: {
                    type: 'alert-success',
                    content: 'cancel account successfull'
                }
            }
            return res.status(200).json({ result })
        }
        else if (actionType == 'request') {
            await User.update('activate', 3, 'stt', stt);
            const result = {
                message: {
                    type: 'alert-success',
                    content: 'request account successfull'
                }
            }
            return res.status(200).json({ result })
        }
        else if (actionType == 'unlock') {
            await User.update('block', 0, 'stt', stt);
            const result = {
                message: {
                    type: 'alert-success',
                    content: 'Unlock account successfull'
                }
            }
            return res.status(200).json({ result })
        }
        else if (actionType == 'disagree') {
            await Histories.update('status', 'Rejected', 'stt', stt);
            const result = {
                message: {
                    type: 'alert-success',
                    content: 'disagree transaction successfull'
                }
            }
            return res.status(200).json({ result });
        }
        else if (actionType == 'agree') {

            const currentHistory = await Histories.get('stt', stt)
            var username = currentHistory.historyData[0].username;
            var transaction = currentHistory.historyData[0].transaction;
            var amount = parseInt(currentHistory.historyData[0].amount);

            console.log(username, transaction, amount)

            if (transaction == 'Withdraw') {
                const currentMoney = await Money.get('username', username);
                const availableBalance = parseInt(currentMoney.userData.balance)

                if (availableBalance < amount + amount * 5 / 100) {
                    const result = {
                        message: {
                            type: 'alert-warning',
                            content: `account '${username}' don't have enough money`
                        }
                    }
                    return res.status(200).json({ result });
                }

                await Money.update('balance', `balance - ${amount} - ${amount * 5 / 100}`, 'username', username);
                await Histories.update('status', 'Approved', 'stt', stt);
                const result = {
                    message: {
                        type: 'alert-success',
                        content: 'agree transaction successfull'
                    }
                }
                return res.status(200).json({ result });
            }

            if (transaction == 'Transfer') {
                var ID = currentHistory.historyData[0].ID
                var date = new Date()

                const currentDetail = await Details.get('ID', ID)
                var bearer = currentDetail.detailData.bearer;
                var rcpPhone = currentDetail.detailData.recipphone;

                var receipientUser = await User.get('phone', rcpPhone)
                var rcpUsername = receipientUser.userData.username;
                var rcpEmail = receipientUser.userData.email;

                let feeForMail = 0
                if (bearer == 'you') {
                    const currentMoney = await Money.get('username', username);
                    const availableBalance = parseInt(currentMoney.userData.balance)

                    if (availableBalance < amount) {
                        const result = {
                            message: {
                                type: 'alert-warning',
                                content: `account '${username}' don't have enough money`
                            }
                        }
                        return res.status(400).json({ result });
                    }

                    if (availableBalance - amount < amount * 5 / 100) {
                        const result = {
                            message: {
                                type: 'alert-warning',
                                content: `account '${username}' don't have enough money for fee transfer`
                            }
                        }
                        return res.status(400).json({ result });
                    }

                    await Money.update('balance', `balance - ${amount} - ${amount * 5 / 100}`, 'username', username);
                    await Money.update('balance', `balance + ${amount}`, 'username', rcpUsername);

                }
                else {

                    const currentRcpMoney = await Money.get('username', rcpUsername);
                    const availableBalance = parseInt(currentRcpMoney.userData.balance)

                    if (availableBalance + amount < amount * 5 / 100) {
                        const result = {
                            message: {
                                type: 'alert-warning',
                                content: `account '${username}' don't have enough money for fee transfer`
                            }
                        }
                        return res.status(400).json({ result });
                    }
                    feeForMail = amount * 5 / 100
                    await Money.update('balance', `balance - ${amount}`, 'username', username);
                    await Money.update('balance', `balance + ${amount} - ${amount * 5 / 100}`, 'username', rcpUsername);

                }

                const numberOfReceive = await Histories.getTotal('transaction', 'Receive')
                var rcpID = 'RC' + numberOfReceive.total;
                var rcpIcon = '/img/Receive.png';

                var histories = new Histories({
                    ID: rcpID,
                    username: rcpUsername,
                    icon: rcpIcon,
                    transaction: 'Receive',
                    amount: amount,
                    time: date,
                    status: 'Approved'
                });

                await Histories.insert(histories);

                await Histories.update('status', 'Approved', 'stt', stt);


                const moneyRecipientUserInfo = await Money.get('username', rcpUsername)
                const userInfo = await User.get('username', username)

                const content = `You just received a transfer from \n`
                     + userInfo.userData.fullname + '\n    Amount: +' + amount
                     + '\n    Fee: -' + feeForMail
                     + '\n    Your balance: ' + moneyRecipientUserInfo.userData.balance

                await sendMailFunction.sendMail(rcpEmail, 'Notice of receipt of money', content)


                const result = {
                    message: {
                        type: 'alert-success',
                        content: 'agree transaction successfull'
                    }
                }
                return res.status(200).json({ result });
            }
        }
    }
}
module.exports = new HomeController;