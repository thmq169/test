const User = require('../models/user');
const Account = require('../models/account');
const bcrypt = require("bcrypt")

class LoginController {
    get(req, res) {
        if (req.session.login) {
            return res.redirect('/');
        }
        else if (req.session.changepassfirst) {
            return res.redirect('/changepassfirst');
        }
        return res.render('login', { title: 'Login' });
    }

    async post(req, res) {
        const username = req.body.username;
        const password = req.body.password;
        console.log(username)
        if (username == 'admin' && password == '123456') {
            req.session.login = true;
            req.session.username = username;
            req.session.admin = true
            return res.redirect('/');
        }

        //check username
        const currentUser = await User.find('username', username)
        let currentAccount = await Account.get('username', username)

        if (currentUser.hasError || !currentUser.exist) {
            return res.render('login', { err: true, username, msg: 'Username is not correct.', title: 'Login' })
        }

        if (currentUser.userData.block) {
            return res.render('login', { err: true, username, msg: 'Account has been locked due to entering the wrong password many times, please contact the administrator for support.', title: 'Login' });
        }

        if (currentUser.userData.activate == 2) {
            return res.render('login', { err: true, username, msg: 'This account has been disabled, please contact hotline 18001008.', title: 'Login' });
        }

        var date = new Date();

        if (currentAccount.accountData.time > date) {
            return res.render('login', { err: true, username, msg: 'Account is currently locked, please try again in 1 minute.', title: 'Login' });
        }

        if (!await bcrypt.compare(password, currentUser.userData.password)) {
            currentAccount = await Account.get('username', username)
            if (currentAccount.accountData.wrongtimes === 2) {
                await Account.update('anlg', '1', 'username', username);

                await Account.update('wrongtimes', `wrongtimes + ${1}`, 'username', username)

                var locktime = date.setMinutes(date.getMinutes() + 1);
                await Account.update('time', `'${locktime}'`, 'username', username);

                return res.render('login', { err: true, username, msg: 'Account is currently locked, please try again in 1 minute.', title: 'Login' });
            }

            if (currentAccount.accountData.wrongtimes === 5 && currentAccount.accountData.anlg) {
                await Account.update('wrongtimes', '0', 'username', username);
                await Account.update('anlg', '0', 'username', username);
                await User.update('block', '1', 'username', username);

                const d = new Date();
                await User.update('dateUpdate', d.toString(), 'username', username)
                return res.render('login', { err: true, username, msg: 'Account has been locked due to entering the wrong password many times, please contact the administrator for support', title: 'Login' });
            }
            if (username != 'admin') {
                await Account.update('wrongtimes', `wrongtimes + ${1}`, 'username', username)
            }
            return res.render('login', { err: true, username, msg: 'Passwork is not correct.', title: 'Login' })

        } else {
            await Account.update('wrongtimes', '0', 'username', username);
            await Account.update('anlg', '0', 'username', username);
            await User.update('block', '0', 'username', username);
            req.session.login = true;
            req.session.username = username;
            return res.redirect('/changepassfirst');
        }
    }
}

module.exports = new LoginController;
