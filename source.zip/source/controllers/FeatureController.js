const Money = require('../models/money');
const Creditcard = require('../models/creditcard');
const Histories = require('../models/histories');
const Details = require('../models/details');
const User = require('../models/user');
const Phonecard = require('../models/phonecard');
const randomFunction = require('../libs/randomFunction.js')
const sendMailFunction = require('../libs/sendMail.js')

function isNumber(value) {
    if (typeof value === "string") {
        return !isNaN(value);
    }
}

class FeatureController {
    async postDeposit(req, res) {
        const username = req.session.username;

        let { card, exp, cvv, amount } = req.body

        card = card.trim()
        exp = exp.trim()
        cvv = cvv.trim()

        if (card !== '111111' && card !== '222222' && card !== '333333') {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: "Card isn't supported"
                }
            }
            return res.status(400).json({ result });
        }

        if (!isNumber(card) || card.includes('e')) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Card number has 6 characters of number.'
                }
            }
            return res.status(400).json({ result });
        }

        if (card == '') {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Please enter card number.'
                }
            }
            return res.status(400).json({ result });
        }

        if (card.length != 6) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Card number has 6 characters.'
                }
            }
            return res.status(400).json({ result });
        }

        if (exp == '') {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Please choose expiration.'
                }
            }
            return res.status(400).json({ result });
        }

        if (cvv == '') {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Please enter CVV.'
                }
            }
            return res.status(400).json({ result });
        }

        if (cvv.length != 3) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'CVV number has 3 characters.'
                }
            }
            return res.status(400).json({ result });
        }

        if (!isNumber(cvv) || cvv.includes('e')) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'CVV number has 3 characters of number.'
                }
            }
            return res.status(400).json({ result });
        }

        else if (amount == '' || amount == 0) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Please enter amount.'
                }
            }
            return res.status(400).json({ result });
        }

        if (amount < 0) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Amount money is not a negative number.'
                }
            }
            return res.status(400).json({ result });
        }

        if (card == '333333') {
            const credit = await Creditcard.get('cardnum', card)

            if (credit.creditData.exp != exp) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'The expiration is not correct'
                    }
                }
                return res.status(400).json({ result });
            }

            if (credit.creditData.cvv != cvv) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'The CVV is not correct'
                    }
                }
                return res.status(400).json({ result });
            }

            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'This card is out of money'
                }
            }
            return res.status(400).json({ result });
        }

        if (card == '222222') {
            const credit = await Creditcard.get('cardnum', card)

            if (credit.creditData.exp != exp) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'The expiration is not correct'
                    }
                }
                return res.status(400).json({ result });
            }

            if (credit.creditData.cvv != cvv) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'The CVV is not correct'
                    }
                }
                return res.status(400).json({ result });
            }


            if (parseInt(amount, 10) > 1000000) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'This card can only be loaded up to 1 million VND per time'
                    }
                }
                return res.status(400).json({ result });
            }

            const numberOfDeposit = await Histories.getTotal('transaction', 'Deposit')

            let ID = 'DB' + numberOfDeposit.total
            let icon = '/img/Deposit.png';
            let date = new Date();

            var histories = new Histories({
                ID,
                username,
                icon,
                transaction: 'Deposit',
                amount,
                time: date,
                status: 'Approved'
            })

            const currentMoney = await Money.get('username', username)

            const oldBalance = currentMoney.userData.balance

            const newBalance = parseInt(amount) + oldBalance;

            const newTransaction = await Histories.insert(histories)

            const unpdateMoney = await Money.update('balance', `${amount} + ${oldBalance}`, 'username', username);

            const result = {
                isSuccess: true,
                newBalance: newBalance,
                message: {
                    type: 'alert-success',
                    content: 'Deposit successfully'
                }
            }

            if (newTransaction.status == 'success' && unpdateMoney.status == 'success') {
                return res.status(200).json({ result });
            }
        }

        const credit = await Creditcard.get('cardnum', card)

        if (credit.creditData.exp != exp) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'The expiration is not correct'
                }
            }
            return res.status(400).json({ result });
        }

        if (credit.creditData.cvv != cvv) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'The CVV is not correct'
                }
            }
            return res.status(400).json({ result });
        }

        const creditCard = await Creditcard.find('cardnum', card)
        console.log(creditCard)
        if (creditCard.hasError || !creditCard.exist) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'This card is not supported.'
                }
            }
            return res.status(400).json({ result });
        }



        const numberOfDeposit = await Histories.getTotal('transaction', 'Deposit')

        let ID = 'DB' + numberOfDeposit.total
        let icon = '/img/Deposit.png';
        let date = new Date();

        var histories = new Histories({
            ID,
            username,
            icon,
            transaction: 'Deposit',
            amount,
            time: date,
            status: 'Approved'
        })

        const currentMoney = await Money.get('username', username)

        const oldBalance = currentMoney.userData.balance

        const newBalance = parseInt(amount) + oldBalance;

        const newTransaction = await Histories.insert(histories)

        const unpdateMoney = await Money.update('balance', `${amount} + ${oldBalance}`, 'username', username);

        const result = {
            isSuccess: true,
            newBalance: newBalance,
            message: {
                type: 'alert-success',
                content: 'Deposit successfully'
            }
        }

        if (newTransaction.status == 'success' && unpdateMoney.status == 'success') {
            return res.status(200).json({ result });
        }
    }

    async postWithdraw(req, res) {
        const username = req.session.username;

        let { card, exp, cvv, amount, note } = req.body
        amount = parseInt(amount)

        if (!isNumber(card) || card.includes('e')) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Card number has 6 characters of number.'
                }
            }
            return res.status(400).json({ result });
        }


        if (card == '') {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Please enter card number.'
                }
            }
            return res.status(400).json({ result });
        }

        if (card.length != 6) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Card number has 6 characters.'
                }
            }
            return res.status(400).json({ result });
        }

        if (card != '111111') {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'This card is not supported'
                }
            }
            return res.status(400).json({ result });
        }

        if (exp == '') {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Please choose expiration.'
                }
            }
            return res.status(400).json({ result });
        }

        if (cvv == '') {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Please enter CVV.'
                }
            }
            return res.status(400).json({ result });
        }

        if (cvv.length != 3) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'CVV number has 3 characters.'
                }
            }
            return res.status(400).json({ result });
        }

        if (!isNumber(cvv) || cvv.includes('e')) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'CVV number has 3 characters of number.'
                }
            }
            return res.status(400).json({ result });
        }

        else if (amount == '' || amount == 0) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Please enter amount.'
                }
            }
            return res.status(400).json({ result });
        }

        if (amount < 0) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Amount money is not a negative number.'
                }
            }
            return res.status(400).json({ result });
        }


        const currentMoney = await Money.get('username', username)

        let { balance, date, time } = currentMoney.userData
        balance = parseInt(balance)

        const credit = await Creditcard.get('cardnum', card)

        if (credit.creditData.exp != exp) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'The expiration is not correct'
                }
            }
            return res.status(400).json({ result });
        }

        if (credit.creditData.cvv != cvv) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'The CVV is not correct'
                }
            }
            return res.status(400).json({ result })
        }

        if (amount % 50000 != 0) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Amount must be a multiple of 50,000 VND'
                }
            }
            return res.status(400).json({ result })
        }

        if ((amount + (amount * 5 / 100)) > balance) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Your balance is not enough'
                }
            }
            return res.status(400).json({ result })
        }

        var d = new Date()
        var current = new Date(d.toLocaleString('en-US', { timeZone: 'Asia/Saigon' }));

        if (current > date) {
            Money.update('time', 0, 'username', username);
            time = 0;
        }

        if (time == 2) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Only 2 withdrawls can be made perday. Please try again tomorrow'
                }
            }
            return res.status(400).json({ result })
        }

        const numberOfWithdraw = await Histories.getTotal('transaction', 'Withdraw')
        var ID = 'WD' + numberOfWithdraw.total
        var icon = '/img/Withdraw.png'

        var nextday = current.setDate(d.getDate() + 1)

        Money.update('date', nextday, 'username', username)
        Money.update('time', 'time + 1', 'username', username)

        var details = new Details({
            ID: ID,
            username: username,
            carrier: '0',
            domination: '0',
            code: '0',
            time: d,
            recipphone: '0',
            recipname: '0',
            bearer: '0',
            note: note
        })

        Details.insert(details, (err) => { });

        if (parseInt(amount) > 5000000) {
            var histories = new Histories({
                ID: ID,
                username: username,
                icon: icon,
                transaction: 'Withdraw',
                amount: amount,
                time: d,
                status: 'Pending approval'
            })
            const newTransaction = await Histories.insert(histories)

            const result = {
                isSuccess: true,
                newBalance: balance,
                message: {
                    type: 'alert-success',
                    content: 'Withdraw successfully and pending approval by admin'
                }
            }

            if (newTransaction.status == 'success') {
                return res.status(200).json({ result });
            }
        }
        else {
            var histories = new Histories({
                ID: ID,
                username: username,
                icon: icon,
                transaction: 'Withdraw',
                amount: amount,
                time: d,
                status: 'Approved'
            })

            const currentMoney = await Money.get('username', username)

            const oldBalance = currentMoney.userData.balance

            const newBalance = oldBalance - parseInt(amount) - parseInt(parseInt(amount) * 5 / 100);

            const newTransaction = await Histories.insert(histories)
            const unpdateMoney = await Money.update('balance', `${newBalance}`, 'username', username);

            const result = {
                isSuccess: true,
                newBalance: newBalance,
                message: {
                    type: 'alert-success',
                    content: 'Withdraw successfully'
                }
            }

            if (newTransaction.status == 'success' && unpdateMoney.status == 'success') {
                return res.status(200).json({ result });
            }
        }
    }

    async postRecipientName(req, res) {
        let { phone } = req.body

        const recipient = await User.find('phone', phone)

        if (!recipient.exist) {
            const result = {
                exist: false
            }
            return res.json({ result })
        }

        const result = {
            exist: true,
            recipientName: recipient.userData.fullname
        }
        return res.json({ result })
    }

    async postTransfer(req, res) {
        const username = req.session.username;
        const currentUser = await User.get('username', username)
        const fullnameUser = currentUser.userData.fullname
        const email = currentUser.userData.email
        if (req.body.sendfor == 'sendagain') {

            var otp = randomFunction.randomOTP();
            Money.update('otp', otp, 'username', username)

            // SEND MAIL
            const content = `Your OTP to tranfer. Don't send for anyone \n`
                + `    OTP: ` + otp
            await sendMailFunction.sendMail(email, 'OTP info', content)

            var date = new Date();
            var limitaion = date.setMinutes(date.getMinutes() + 1);
            Money.update('otptime', limitaion, 'username', username)

            const result = {
                message: {
                    type: 'alert-success',
                    content: 'create new otp successfull'
                }
            }
            return res.status(200).json({ result })
        }
        else if (req.body.sendfor == 'enterotp') {
            var rcpPhone = req.session.rcpPhone;
            var amount = req.session.amount;
            var bearer = req.session.bearer;
            var note = req.session.note;

            var otp = req.body.otp;
            var date = new Date();

            if (otp == '') {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'Please enter OTP'
                    }
                }
                return res.status(400).json({ result })
            }

            const currentMoney = await Money.get('username', username)

            if (currentMoney.userData.otp != otp) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'OTP is not correct'
                    }
                }
                return res.status(400).json({ result })
            }

            if (currentMoney.userData.otptime < date) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'OTP is invalidate, please click \'Send again\' to get new OTP'
                    }
                }
                return res.status(400).json({ result })
            }

            const recipientUser = await User.get('phone', rcpPhone)
            let rcpName = recipientUser.userData.fullname
            let rcpUsername = recipientUser.userData.username
            let rcpEmail = recipientUser.userData.email

            let numberOfTransfer = await Histories.getTotal('transaction', 'Transfer')

            let ID = 'TF' + numberOfTransfer.total
            let icon = '/img/Transfer.png'

            var details = new Details({
                ID: ID,
                username: username,
                carrier: '0',
                domination: '0',
                code: '0',
                time: date,
                recipphone: rcpPhone,
                recipname: rcpName,
                bearer: bearer,
                note: note
            })

            Details.insert(details, (err) => { })

            if (amount > 5000000) {
                var histories = new Histories({
                    ID: ID,
                    username: username,
                    icon: icon,
                    transaction: 'Transfer',
                    amount: amount,
                    time: date,
                    status: 'Pending approval'
                });

                const newTransaction = await Histories.insert(histories);

                req.session.rcpPhone = null;
                req.session.amount = null;
                req.session.bearer = null;
                req.session.note = null;

                if (newTransaction.status == 'success') {
                    const result = {
                        isSuccess: true,
                        currentBalance: currentMoney.userData.balance,
                        message: {
                            type: 'alert-success',
                            content: 'Transfer successfully and pending approval'
                        }
                    }
                    return res.status(200).json({ result })
                }
            }
            else {
                let numberOfTransfer = await Histories.getTotal('transaction', 'Receive')
                let rcpID = 'RC' + numberOfTransfer.total;
                let rcpIcon = '/img/Receive.png';

                var histories = new Histories({
                    ID: ID,
                    username: username,
                    icon: icon,
                    transaction: 'Transfer',
                    amount: amount,
                    time: date,
                    status: 'Approved'
                });

                const newTransfer = await Histories.insert(histories);

                var histories = new Histories({
                    ID: rcpID,
                    username: rcpUsername,
                    icon: rcpIcon,
                    transaction: 'Receive',
                    amount: amount,
                    time: date,
                    status: 'Approved'
                });

                const newReceive = await Histories.insert(histories);

                var details = new Details({
                    ID: rcpID,
                    username: username,
                    carrier: '0',
                    domination: '0',
                    code: '0',
                    time: date,
                    recipphone: '0',
                    recipname: '0',
                    bearer: bearer,
                    note: note
                })

                Details.insert(details, (err) => { })
                
                let feeForMail = 0
                if (bearer == 'you') {
                    await Money.update('balance', `balance - ${amount} - ${amount * 5 / 100}`, 'username', username);
                    await Money.update('balance', `balance + ${amount}`, 'username', rcpUsername);
                }
                else {
                    feeForMail = amount * 5 / 100
                    await Money.update('balance', `balance - ${amount}`, 'username', username);
                    await Money.update('balance', `balance + ${amount} - ${amount * 5 / 100}`, 'username', rcpUsername);
                }

                req.session.rcpPhone = null;
                req.session.amount = null;
                req.session.bearer = null;
                req.session.note = null;

                const currentMoney = await Money.get('username', username)
                const currentBalance = currentMoney.userData.balance

                const moneyRecipientUserInfo = await Money.get('username', rcpUsername)
                
                const content = `You just received a transfer from \n`
                     + fullnameUser + '\n    Amount: +' + amount
                     + '\n    Fee: -' + feeForMail
                     + '\n    Your balance: ' + moneyRecipientUserInfo.userData.balance

                await sendMailFunction.sendMail(rcpEmail, 'Notice of receipt of money', content)

                const result = {
                    isSuccess: true,
                    currentBalance: currentBalance,
                    message: {
                        type: 'alert-success',
                        content: 'Transfer successfully'
                    }
                }
                return res.status(200).json({ result })
            }

        }
        if (req.body.sendfor == 'entersubmit') {
            let { rcpPhone, amount, note, bearer } = req.body

            if (rcpPhone == '') {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'Please enter phone number of the recipient'
                    }
                }
                return res.status(400).json({ result })
            }

            const rcpPUser = await User.get('phone', rcpPhone)
            if (!rcpPUser.userData) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'Phone number is not exist'
                    }
                }
                return res.status(400).json({ result })
            }

            if (amount == '' || amount == 0) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'Please enter amount money to transfer'
                    }
                }
                return res.status(400).json({ result })
            }

            if (amount < 0) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'Amount money is not a negative number.'
                    }
                }
                return res.status(400).json({ result });
            }

            if (bearer == '') {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'Please choice a bearer for fee'
                    }
                }
                return res.status(400).json({ result })
            }



            amount = parseInt(amount);

            const currentMoney = await Money.get('username', username)
            let balance = currentMoney.userData.balance

            if (amount > balance) {
                const result = {
                    message: {
                        type: 'alert-warning',
                        content: 'Your balance is not enough'
                    }
                }
                return res.status(400).json({ result })
            }

            if (bearer == 'you') {
                if (amount + (amount * 5 / 100) > balance) {
                    const result = {
                        message: {
                            type: 'alert-warning',
                            content: 'Your balance is not enough for fee'
                        }
                    }
                    return res.status(400).json({ result })
                }
            }

            if (bearer == 'recipient') {
                const rcpUserMoney = await Money.get('username', username)

                if (rcpUserMoney.userData.balance + amount < (amount * 5 / 100)) {
                    const result = {
                        message: {
                            type: 'alert-warning',
                            content: 'the balance of recipient is not enough'
                        }
                    }
                    return res.status(400).json({ result })
                }
            }

            let otp = randomFunction.randomOTP()

            await Money.update('otp', otp, 'username', username)

            const content = `Your OTP to tranfer. Don't send for anyone \n`
                + `    OTP: ` + otp
            await sendMailFunction.sendMail(email, 'OTP info', content)

            let date = new Date()
            var limitaion = date.setMinutes(date.getMinutes() + 1)

            await Money.update('otptime', limitaion, 'username', username)

            req.session.rcpPhone = rcpPhone
            req.session.amount = amount
            req.session.bearer = bearer
            req.session.note = note

            const result = {
                success: true,
                message: {
                    type: 'alert-success',
                    content: 'waiting enter otp'
                }
            }
            return res.status(400).json({ result })
        }
    }

    async postBuyphonecard(req, res) {
        const username = req.session.username;
        const { carrier, domination, amount } = req.body;

        if (amount == '' || amount == 0) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Please enter amount'
                }
            }
            return res.status(400).json({ result })
        }

        if (amount < 0) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Amount money is not a negative number.'
                }
            }
            return res.status(400).json({ result });
        }

        if (amount > 5) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'You can only buy up to 5 cards at a time'
                }
            }
            return res.status(400).json({ result })
        }

        let currentMoney = await Money.get('username', username)
        if (currentMoney.userData.balance - (amount * domination) < 0) {
            const result = {
                message: {
                    type: 'alert-warning',
                    content: 'Your balance is not enough'
                }
            }
            return res.status(400).json({ result })
        }

        var price = amount * domination;
        var date = new Date();

        const totalBuyCard = await Histories.getTotal('transaction', 'Buy card')
        var ID = 'BC' + totalBuyCard.total;
        var icon = '/img/Buyphonecard.png';

        var histories = new Histories({
            ID: ID,
            username: username,
            icon: icon,
            transaction: 'Buy card',
            amount: price,
            time: date,
            status: 'Approved'
        });

        await Histories.insert(histories);

        const phoneCard = await Phonecard.get('carrier', carrier)
        var code = phoneCard.phoneCardData.code
        var card = ''
        var cardArr = []

        for (let i = 0; i < amount; i++) {
            //create random phone card
            card = code + randomFunction.randomCard();
            cardArr.push(card);

            var details = new Details({
                ID: ID,
                username: username,
                carrier: carrier,
                domination: domination,
                code: card,
                time: date,
                recipphone: '0',
                recipname: '0',
                bearer: '0',
                note: null
            })

            Details.insert(details, (err) => { });
        }

        await Money.update('balance', `balance - ${price}`, 'username', username);

        currentMoney = await Money.get('username', username)

        const currentBalance = currentMoney.userData.balance

        const result = {
            isSuccess: true,
            currentBalance: currentBalance,
            cardArr,
            message: {
                type: 'alert-success',
                content: 'Buy card successfully'
            }
        }
        return res.status(200).json({ result })
    }

    async getHistory(req, res) {
        const username = req.session.username;

        const histories = await Histories.get('username', username)
        const historyData = histories.historyData

        const details = await Details.getAll()
        const detailData = await details.detailData

        return res.status(200).json({ historyData, detailData })
    }

    async getActiveInfo(req, res) {
        if (!req.session.username || !req.session.login) {
            return res.redirect('/login')
        }

        const username = req.session.username;
        let currentUser = await User.get('username', username)

        let result = {};
        switch (currentUser.userData.activate) {
            case 0:
                result = {
                    userActivate: false,
                    type: 'no-activate',
                    message: {
                        type: 'alert-warning',
                        content: 'This feature is only available for verified accounts. Please wait for admin approved'
                    }
                }
                break;

            case 1:
                result = {
                    userActivate: true,
                    type: 'activate',
                    message: {
                        type: 'alert-success',
                        content: 'activate'
                    }
                }
                break;

            case 3:
                result = {
                    userActivate: false,
                    type: 'miss-IC',
                    message: {
                        type: 'alert-warning',
                        content: 'Your identify card is missing or invalid. You must re-upload your photo of ID card first to use this feature'
                    }
                }
                break;

            case 4:
                result = {
                    userActivate: false,
                    type: 'miss-IC',
                    message: {
                        type: 'alert-warning',
                        content: 'Your identify card is waiting for verify by admin. Please waiting to use this feature'
                    }
                }
                break;

            default:
                break;
        }

        return res.status(200).json({ result })
    }

    // ADMIN 
    async getWaitinglist(req, res) {
        if (!req.session.login) {
            return res.json({ hasError: false })
        }
        else {
            const users = await User.queryForWaitingList()
            return res.json({ userData: users })
        }
    }

    async getActivatedlist(req, res) {
        if (!req.session.login) {
            return res.json({ hasError: false })
        }
        else {
            const users = await User.gets('activate', 1)
            return res.json({ userData: users })
        }
    }

    async getDisabledlist(req, res) {
        if (!req.session.login) {
            return res.json({ hasError: false })
        }
        else {
            const users = await User.gets('activate', 2)
            return res.json({ userData: users })
        }
    }

    async getLockedlist(req, res) {
        if (!req.session.login) {
            return res.json({ hasError: false })
        }
        else {
            const users = await User.queryForBlockList()
            return res.json({ userData: users })
        }
    }

    async getTransactionlist(req, res) {
        if (!req.session.login) {
            return res.json({ hasError: false })
        }
        else {
            // const histories = await Histories.gets('username', username)
            const histories = await Histories.get('status', 'Pending approval')
            const historyData = histories.historyData

            const details = await Details.getAll()
            const detailData = await details.detailData

            return res.json({ historyData, detailData })
        }
    }
}

module.exports = new FeatureController;