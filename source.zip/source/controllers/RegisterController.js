const User = require('../models/user');
const Account = require('../models/account');
const Money = require('../models/money');
const randomFunction = require('../libs/randomFunction.js')
const cloudinary = require('../utils/cloudinary.js')
const nodemailer = require('nodemailer')
const bcrypt = require("bcrypt")

function sendMail(to, subject, content) {
    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'nguyenhuy7402@gmail.com',
            pass: 'qheucmftieulsyzc'
        }
    })

    let mailOptions = {
        from: 'nguyenhuy7402@gmail.com',
        to,
        subject,
        text: content
    }

    return new Promise((resolve, reject) => {
        transporter.sendMail(mailOptions, function (err, info) {
            if (err) {
                console.log(err)
                resolve({
                    status: 'send mail fail'
                })
            } else {
                console.log('send to: ' + info.response)
                resolve({
                    status: 'send mail successfully'
                })
            }
        })
    })
}

class RegisterController {
    get(req, res) {
        if (req.session.login) {
            return res.redirect('/');
        }
        res.render('register', { title: 'Register' });
    }

    async post(req, res) {
        let fullname = req.body.fullname;
        let email = req.body.email;
        let phone = req.body.phone;
        let birthday = req.body.birthday;
        let address = req.body.address;
        let frontIC = null;
        let backIC = null;

        if (fullname == '') {
            return res.render('register', { err: true, fullname, phone, email, birthday, address, msg: 'Fullname is required', title: 'Register' });
        }

        if (email == '') {
            return res.render('register', { err: true, fullname, phone, email, birthday, address, msg: 'Email is required', title: 'Register' });
        }

        if (phone == '') {
            return res.render('register', { err: true, fullname, phone, email, birthday, address, msg: 'Phone number is required', title: 'Register' });
        }

        if (birthday == '') {
            return res.render('register', { err: true, fullname, phone, email, birthday, address, msg: 'Birthday is required', title: 'Register' });
        }

        if (address == '') {
            return res.render('register', { err: true, fullname, phone, email, birthday, address, msg: 'Address is required', title: 'Register' });
        }

        const checkExistPhone = await User.find('phone', phone)

        if (checkExistPhone.hasError || checkExistPhone.exist) {
            return res.render('register', { err: true, fullname, email, birthday, address, msg: 'This phone number is existed', title: 'Register' });
        }

        const checkExistEmail = await User.find('email', email)

        if (checkExistEmail.hasError || checkExistEmail.exist) {
            return res.render('register', { err: true, fullname, phone, birthday, address, msg: 'This email is existed', title: 'Register' });
        }

        const uploader = async (path) => await cloudinary.uploads(path, email)

        const files = req.files;

        if (files.frontIC) {
            const frontIC_Path = files.frontIC[0].path
            const newFrontIC = await uploader(frontIC_Path)
            frontIC = newFrontIC.url
        }

        if (files.backIC) {
            const backIC_Path = files.backIC[0].path
            const newBackIC = await uploader(backIC_Path)
            backIC = newBackIC.url
        }

        let username = randomFunction.randomUsername();
        let password = randomFunction.randomPassword();
        let hasPassword = await bcrypt.hash(password, 11)
        const d = new Date();
        
        let newUserData = new User({
            fullname,
            email,
            phone,
            birthday,
            address,
            username,
            password: hasPassword,
            checkfirst: 0,
            activate: 0,
            block: 0,
            frontIC: frontIC,
            backIC: backIC,
            dateCreate: d.toString(),
            dateUpdate: d.toString()
        })

        let newAccountData = new Account({
            username,
            wrongtimes: 0,
            anlg: 0,
            time: '0'
        })

        let newMoneyData = new Money({
            username,
            balance: 0,
            time: 0,
            date: '0',
            otp: '0',
            otptime: '0'
        })

        const newUser = await User.insert(newUserData);
        const newMoney = await Money.insert(newMoneyData);
        const newAccount = await Account.insert(newAccountData);

        const content = `This is username and password for your wallet don't send for anyone \n`
            + `    username: ` + username + '\n    password: ' + password
        await sendMail(email, 'username and password info', content)

        if (newUser.status == 'success' && newMoney.status == 'success' && newAccount.status == 'success') {
            return res.redirect('/login');
        }
    }
}

module.exports = new RegisterController;