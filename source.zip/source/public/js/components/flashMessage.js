const mapMessageTypeWithIcon = {
    'alert-primary': '<svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Info:"><use xlink:href="#info-fill"/></svg>',
    'alert-success': '<svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>',
    'alert-warning': '<svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Warning:"><use xlink:href="#exclamation-triangle-fill"/></svg>'
}

export function FlashMessage(message) {
    return `<div id="myAlert" 
                  style="font-size: 16px;"
                  class="alert ${message.type} d-inline-block align-items-center show" role="alert">
                  ${mapMessageTypeWithIcon[message.type]}
                  <div class="d-inline-block">
                    ${message.content}
                  </div>
              </div>`
}
