export function showAbout() {
    return `
        <div style="height:500px; display: flex; align-items: center; justify-content: center;">
            <div>
                <h1 style="text-align: center;">EWalllet</h1>
                <h2 style="display: block; text-align: center;">Make by TDT student</h2>
            </div>
        </div>    
    `
}