export function showUserProfile(userInfo) {
    const date = new Date(userInfo.birthday)
    let dateTime = date.getDate()
    let monthTime = date.getMonth() + 1

    if (dateTime < 10) {
        dateTime = '0' + dateTime
    }

    if (monthTime < 10) {
        monthTime = '0' + monthTime
    }

    const formatDate = dateTime + '/' + monthTime + '/' + date.getFullYear()

    return `
   
        <h3 class="mt-2 mb-2 text-primary fw-bold">
            My profile
                
        </h3>
        <div class="row align-items-center">
                            
            <div class="col-lg-6 px-xl-10" style='display:flex; justify-content:center'>
                <div>
                    <div class="bg-secondary d-lg-inline-block py-1-9 px-1-9 px-sm-6 mb-1-9 rounded">
                        <h3 class="h2 text-white mb-0">${userInfo.fullname}</h3>
                    </div>
                    <ul class="list-unstyled mb-1-9">
                        <li class="mb-2 mb-xl-3 display-28">
                            <span class="display-26 text-secondary me-2 font-weight-600">Status:</span>   
                        `
        +
        `${userInfo.activate == 1 ? `<span class="text-success" style="font-size: 16px">(verified)</span>` : ``}`
        +
        `${userInfo.activate == 3 ? `<span class="text-warning" style="font-size: 16px">(wating update identify card)</span>` : ``}`
        +
        `${userInfo.activate == 4 ? `<span class="text-warning" style="font-size: 16px">(waiting verify identity card by admin)</span>` : ``}`
        +
        `${userInfo.activate == 0 ? `<span class="text-warning" style="font-size: 16px">(wating verify by admin)</span>` : ``}`
        +
        `
                        </li>
                        <li class="mb-2 mb-xl-3 display-28"><span class="display-26 text-secondary me-2 font-weight-600">Email:</span> ${userInfo.email}</li>
                        <li class="mb-2 mb-xl-3 display-28"><span class="display-26 text-secondary me-2 font-weight-600">Phone number:</span> ${userInfo.phone}</li>
                        <li class="mb-2 mb-xl-3 display-28"><span class="display-26 text-secondary me-2 font-weight-600">Birthday:</span> ${formatDate}</li>
                        <li class="mb-2 mb-xl-3 display-28"><span class="display-26 text-secondary me-2 font-weight-600">Address:</span> ${userInfo.address}</li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-6 mb-4 mb-lg-0" style='display:flex; justify-content:center'>
                <ul class="list-unstyled mb-1-9">
                    <li class="mb-2 mb-xl-3 display-28">
                        <span class="display-26 text-secondary me-2 font-weight-600">Identity card:</span>
                    </li>
                    <li class="mb-2 mb-xl-3 display-28">
                        `
        +
        `${userInfo.frontIC ? `<a href="${userInfo.frontIC}"><img style='width:330px' src="${userInfo.frontIC}" alt="..."></a>` : `<img style='width:330px' src="/img/default.png" alt="...">`}`
        +
        `
                    </li>

                    <li class="mb-2 mb-xl-3 display-28">
                        `
        +
        `${userInfo.backIC ? `<a href="${userInfo.backIC}"><img style='width:330px' src="${userInfo.backIC}" alt="..."></a>` : `<img style='width:330px' src="/img/default.png" alt="...">`}`
        +
        `
                    </li>
                </ul>
            </div>
                     
            <a class="text-end" href="/profile/changepass">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
                    <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/>
                </svg>
                <span>
                    Change password
                </span>
            </a>
`
            +
        `${userInfo.activate == 3 ? `
                <a class="text-end mt-3" href="/profile/reupIC">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16">
                        <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
                        <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/>
                    </svg>
                        <span>
                            Re-up identity card
                        </span>
                </a>

        ` : ``}`
        +
        `
        </div>

    `
}