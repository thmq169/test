export function showHistory(histories) {
    var html = `
        <h3 class="mt-2 mb-2 text-center text-primary fw-bold">Transaction history</h3>
        <div style="overflow-x:auto;">
        <table cellpadding="10" cellspacing="10" border="0" style="margin: auto; height: 500px; width: 570px; display: block; overflow: auto" >
            <tr class="header">
                <td></td>
                <td>Transaction</td>
                <td>Time</td>
                <td>Status</td>
                <td></td>
            </tr>

    `
    for (let i = 0; i < histories.length; i++) {
        const date = new Date(histories[i].time)
        let dateTime = date.getDate()
        let monthTime = date.getMonth() + 1

        if (dateTime < 10) {
            dateTime = '0' + dateTime
        }

        if (monthTime < 10) {
            monthTime = '0' + monthTime
        }

        const formatDate = dateTime + '/' + monthTime + '/' + date.getFullYear()

        html += `<tr class="item">
                    <td><img style="width:100px" src="${histories[i].icon}"></td>
                    <td>${histories[i].transaction}</td>
                    <td>${formatDate}</td>
                    <td>
                `
            +
            `${histories[i].status == 'Approved' ?
                `<span class="badge rounded-pill bg-success">${histories[i].status}</span>` :
                ``}`
            +
            `${histories[i].status == 'Pending approval' ?
                `<span class="badge rounded-pill bg-warning">${histories[i].status}</span>` :
                ``}`
            +
            `${histories[i].status == 'Rejected' ?
                `<span class="badge rounded-pill bg-danger">${histories[i].status}</span>` :
                ``}`
            +

            `   
                    </td>
                    <td>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#${histories[i].ID}">More</button>
                    </td>
                </tr>`;
    }
    return html + `</table> </div>`;
}