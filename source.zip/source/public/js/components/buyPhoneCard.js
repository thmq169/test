export function buyPhoneCard() {
    return `
        <h3 class="mt-2 mb-2 text-center text-primary fw-bold">Buy phone card</h3>
        <form id="buyPhoneCard_form" class="border p-3 rounded">
                Provider:

                <div class="form-group">
                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input checked type="radio" class="form-check-input" name="carrier" value="Viettel">Viettel
                        </label>

                    </div>

                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="carrier" value="Mobifone">Mobifone
                        </label>
                    </div>

                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="carrier" value="Vinaphone">Vinaphone
                        </label>
                    </div>
                </div>

                Domination:

                <div class="form-group">
                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input checked type="radio" class="form-check-input" name="domination" value="10000">10,000 VND
                        </label>
                    </div>

                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="domination" value="20000">20,000 VND
                        </label>
                    </div>

                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="domination" value="50000">50,000 VND
                        </label>
                    </div>

                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" name="domination" value="100000">100,000 VND
                        </label>
                    </div>
                </div>

                <div class="form-group">
                    <label for="amount">Amount</label>
                    <input type="number" class="form-control" id="amount" placeholder="Amount" name="amount">
                </div>

                <div class="form-group">Transaction fee is 0%.</div> 

                <div class="form-group">
                    <button id="submit_buyPhoneCard_form" class="btn btn-bg-cl-secondary" style="width: 100%">Buy</button>
                </div>
            </form>
    `
}
