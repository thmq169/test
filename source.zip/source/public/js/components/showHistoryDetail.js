export function showHistoryDetail(histories, details) {
    var html = '';
    for (let i = 0; i < histories.length; i++) {
        if (histories[i].transaction == 'Deposit') {
            html += ` <div id='${histories[i].ID}' class='modal fade' role='dialog' >
                        <div class='modal-dialog modal-lg' >
                            <div class='modal-content'>
                                <div class='modal-header'>
                                    <hp class='modal-title'>Details</hp>
                                </div>
                                <div class='modal-body' >
                                    <table cellpadding='10' cellspacing='10' border='0' style='border-collapse: collapse; margin: auto;'>
                                        <tr class='header'>
                                            <td>Transaction code</td>
                                            <td>Transaction fee</td>
                                            <td>Profit</td>
                                            <td>Status</td>
                                        </tr>
                                        <tr class='item'>
                                            <td>${histories[i].ID}</td>
                                            <td> 0 VND</td>
                                            <td>+ ${new Intl.NumberFormat().format(histories[i].amount)} VND</td>
                                            <td>${histories[i].status}</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class='modal-footer'>
                                    <button type='button' class='btn btn-default' data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>`;
        }
        else if (histories[i].transaction == 'Buy card') {
            html += `<div id='${histories[i].ID}' class='modal fade' role='dialog'>
                        <div class='modal-dialog modal-lg'>
                            <div class='modal-content'>
                                <div class='modal-header'>
                                    <hp class='modal-title'>Details</hp>
                                </div>
                                <div class='modal-body'>
                                    <table cellpadding='10' cellspacing='10' border='0' style='border-collapse: collapse; margin: auto'>
                                        <tr class='header'>
                                            <td>Transaction code</td>
                                            <td>Carrier</td>
                                            <td>Domination</td>
                                            <td>Phone card</td>
                                        </tr>`;

            for (let j = 0; j < details.length; j++) {
                if (histories[i].ID == details[j].ID) {
                    html += `<tr class='item'>
                                                    <td>${histories[i].ID}</td>
                                                    <td>${details[j].carrier}</td>
                                                    <td>${new Intl.NumberFormat().format(details[j].domination)} VND</td>
                                                    <td>${details[j].code}</td>
                                                </tr>`
                }
            }

            html += `</table>
                                </div>
                                <div class='modal-footer'>
                                    <button type='button' class='btn btn-default' data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>`;
        }
        else {
            for (let j = 0; j < details.length; j++) {
                if (histories[i].ID == details[j].ID) {
                    if (histories[i].transaction == 'Withdraw') {
                        html += `<div id='${histories[i].ID}' class='modal fade' role='dialog'>
                                    <div class='modal-dialog modal-lg'>
                                        <div class='modal-content'>
                                            <div class='modal-header'>
                                                <hp class='modal-title'>Details</hp>
                                            </div>
                                            <div class='modal-body'>
                                                <table cellpadding='10' cellspacing='10' border='0' style='border-collapse: collapse; margin: auto'>
                                                    <tr class='header'>
                                                        <td>Transaction code</td>
                                                        <td>Transaction fee</td>
                                                        <td>Profit</td>
                                                        <td>Status</td>
                                                    </tr>
                                                    <tr class='item'>
                                                        <td>${histories[i].ID}</td>
                                                        <td>${new Intl.NumberFormat().format(histories[i].amount * 5 / 100)} VND</td>
                                                        <td>- ${new Intl.NumberFormat().format(histories[i].amount)} VND</td>
                                                        <td>${histories[i].status}</td>
                                                    </tr>
                                                    <tr class='header'>
                                                        <td colspan='4'>Note</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan='4'>
                                                            <textarea readonly style='resize:none; width:600px; height:140px'>${details[j].note}</textarea>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class='modal-footer'>
                                                <button type='button' class='btn btn-default' data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>  
                                </div>`;
                    }
                    else if (histories[i].transaction == 'Transfer') {
                        html += `<div id='${histories[i].ID}' class='modal fade' role='dialog'>
                                    <div class='modal-dialog modal-xl'>
                                        <div class='modal-content'>
                                            <div class='modal-header'>
                                                <hp class='modal-title'>Details</hp>
                                            </div>
                                            <div class='modal-body'>
                                                <table cellpadding='10' cellspacing='10' border='0' style='border-collapse: collapse; margin: auto'>
                                                <tr class='header'>
                                                        <td>Transaction code</td>
                                                        <td>Transaction fee</td>
                                                        <td>Profit</td>
                                                        <td>Recipient</td>
                                                        <td>Recipient phone</td>
                                                        <td>Fee payer</td>
                                                        <td>Status</td>
                                                    </tr>
                                                    <tr class='item'>
                                                        <td>${histories[i].ID}</td>
                                                        <td>${new Intl.NumberFormat().format(histories[i].amount * 5 / 100)} VND</td>
                                                        <td>- ${new Intl.NumberFormat().format(histories[i].amount)} VND</td>
                                                        <td>${details[j].recipname}</td>
                                                        <td>${details[j].recipphone}</td>
                                                        <td>${details[j].bearer}</td>
                                                        <td>${histories[i].status}</td>
                                                    </tr>
                                                    <tr class='header'>
                                                        <td colspan='7'>Note</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan='7'>
                                                            <textarea readonly style='resize:none; width:650px; height:140px'>${details[j].note}</textarea>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class='modal-footer'>
                                                <button type='button' class='btn btn-default' data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
                    }
                    else if (histories[i].transaction == 'Receive') {
                        if (details[j].bearer == 'you') {
                            var bearer = 'Sender';
                        }
                        else {
                            var bearer = 'You';
                        }
                        html += `<div id='${histories[i].ID}' class='modal fade' role='dialog'>
                                    <div class='modal-dialog modal-xl'>
                                        <div class='modal-content'>
                                            <div class='modal-header'>
                                                <hp class='modal-title'>Details</hp>
                                            </div>
                                            <div class='modal-body'>
                                                <table cellpadding='10' cellspacing='10' border='0' style='border-collapse: collapse; margin: auto'>
                                                <tr class='header'>
                                                        <td>Transaction code</td>
                                                        <td>Transaction fee</td>
                                                        <td>Profit</td>
                                                        <td>Sender</td>
                                                        <td>Fee payer</td>
                                                        <td>Status</td>
                                                        <td>Note</td>
                                                    </tr>
                                                    <tr class='item'>
                                                        <td>${histories[i].ID}</td>
                                                        <td>${new Intl.NumberFormat().format(histories[i].amount * 5 / 100)} VND</td>
                                                        <td>+ ${new Intl.NumberFormat().format(histories[i].amount)} VND</td>
                                                        <td>${details[j].username}</td>
                                                        <td>${details[j].bearer}</td>
                                                        <td>${histories[i].status}</td>
                                                        <td>${details[j].note}</td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class='modal-footer'>
                                                <button type='button' class='btn btn-default' data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
                    }
                }
            }
        }
    }
    return html;
}