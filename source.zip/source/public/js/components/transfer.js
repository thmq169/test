export function transfer(fullname) {
    return `
    <h3 class="mt-2 mb-2 text-center text-primary fw-bold">Transfer</h3>
    <form id="transfer_form" class="border p-3 rounded">
        <div class="form-group">
            <label for="number">Recipient's phone number</label>
            <input type="text" maxlength="10" minlength="10" class="form-control" id="recipient_phone_number" placeholder="Recipient's number" name="phone">
        </div>

        <div class='form-group' id="recipient_name_area">
            
        </div>

        <div class="form-group">
            <label for="amount">Amount of money</label>
            <input type="number" class="form-control" id="money" placeholder="Amount" name="amount">
        </div>

        <div class="form-group">
            <label for="note">Note</label>
            <textarea class="form-control" id="note" placeholder="Note" name="note">`+ fullname +` transfer</textarea>
        </div>

        <div class="form-group">Transfer fee is 5%. Please choose bearer.</div> 

        <div class="form-group">
            <div class="form-check-inline">
                <label class="form-check-label">
                    <input type="radio" class="form-check-input" name="bearer" value="you" checked>You
                </label>
            </div>

            <div class="form-check-inline">
                <label class="form-check-label">
                    <input type="radio" class="form-check-input" name="bearer" value="recipient">Recipient
                </label>
            </div>
        </div>

        <div class="form-group">
            <button id="submit_transfer_form" class="btn btn-bg-cl-secondary" style="width: 100%">Transfer</button>
        </div>
    </form>

    <div class="modal fade" id="transferModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <hp class='modal-title'>EnterOTP</hp>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type='text' class='form-control' id='otp' placeholder='OTP' name='otp'>
                    
                    <div style='margin-top: 15px; margin-bottom: -20px'>
                        <p>Click here for sending OTP again.<button type='submit' class='btn btn-link' id="reset_otp_btn">Send again</button></p>
                    </div>
                
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type='submit' class='btn btn-primary' id="enter_otp_btn">CONFIRM</button>
                </div>
            </div>
        </div>
    </div>
    `
}