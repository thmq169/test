export function showUserInfo(userData, typeUserTitle, typeUser) {
    var html = `
        <h3 class="mt-2 mb-2 text-center text-primary fw-bold">${typeUserTitle}</h3>
        <div style="overflow-x:auto;">
        <table cellpadding="10" cellspacing="10" border="0" style="border-collapse: collapse; margin: auto">
            <tr class="header">
                <td>ID card (front)</td>
                <td>ID card (back)</td>
                <td>Name</td>
                <td>Email</td>
                <td>Phone</td>
                <td>Birthday</td>
                <td>Address</td>
                <td>Status</td>
                <td></td>
            </tr>

    `
    for (let i = 0; i < userData.length; i++) {
        const user = userData[i]
        const date = new Date(user.birthday)
        let dateTime = date.getDate()
        let monthTime = date.getMonth() + 1

        if (dateTime < 10) {
            dateTime = '0' + dateTime
        }

        if (monthTime < 10) {
            monthTime = '0' + monthTime
        }

        const formatDate = dateTime + '/' + monthTime + '/' + date.getFullYear()

        html += `<tr class="item">
                <td>`
                +
                    `${user.frontIC ? 
                        `
                        <a href="${user.frontIC}">
                            <img style='width:50px' src="${user.frontIC}" alt="...">
                        </a>`
                            : `<img style='width:50px' src="/img/default.png" alt="...">`}`
                    
                +
                `</td>
                <td>`
                +
                `${user.backIC ? 
                    `
                    <a href="${user.backIC}">
                        <img style='width:50px' src="${user.backIC}" alt="...">
                    </a>`
                        : `<img style='width:50px' src="/img/default.png" alt="...">`}`
                
                +
                `
                </td>
                <td>${user.fullname}</td>
                <td>${user.email}</td>
                <td>${user.phone}</td>
                <td>${formatDate}</td>
                <td>${user.address}</td>
                <td>`
                +
                `${typeUser === 'waitingList' && user.activate == 0 ?
                    `<span class="badge rounded-pill bg-warning">waiting verify</span>`
                : ``}`
                +
                `${typeUser === 'waitingList' && user.activate == 3 ?
                    `<span class="badge rounded-pill bg-warning">waiting update</span>`
                : ``}`
                +
                `${typeUser === 'waitingList' && user.activate == 4 ?
                    `<span class="badge rounded-pill bg-warning">waiting verify new identity card</span>`
                : ``}`
                +
                `${typeUser === 'activatedList' ?
                    `<span class="badge rounded-pill bg-success">activated</span>`
                : ``}`
                +
                `${typeUser === 'disabledList' ?
                    `<span class="badge rounded-pill bg-secondary">disabled</span>`
                : ``}`
                +
                
                `${typeUser === 'lockedList' ?
                    `<span class="badge rounded-pill bg-danger">locked</span>`
                : ``}`
                +
                `</td>
                <td>`
                    +
                    `${typeUser === 'waitingList' ?
                        `
                        <div class="btn-group" style="position: unset">
                            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                Action
                            </button>
                            <ul class="dropdown-menu">
                                <li data-id="${user.stt}" data-actionType="verify" class="li-dropdown-action admin-action-for-waiting">
                                    <a class="dropdown-item" style="pointer-events: none">Verify</a></li>
                                <li data-id="${user.stt}" data-actionType="cancel" class="li-dropdown-action admin-action-for-waiting">
                                    <a class="dropdown-item" style="pointer-events: none">Disable</a></li>
                                <li data-id="${user.stt}" data-actionType="request" class="li-dropdown-action admin-action-for-waiting">
                                    <a class="dropdown-item" style="pointer-events: none">Request</a></li>
                            </ul>
                        </div>
                        `
                    : ``}`
                    +                    
                    `${typeUser === 'lockedList' ?
                        `<button data-id="${user.stt}"  data-actionType="unlock" type="button" class="btn btn-success admin-action-for-locked">Unlock</button>`
                    : ``}`
                    +
                    
                `</td>
                </tr>`;
    }
    return html + `</table> </div>
    
    <div class="modal fade" id="unlockModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirm unlock</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Do you really want to unlock this account?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary btn-confirm-unlock-acc">Confirm</button>
        </div>
      </div>
    </div>
  </div>
    
    `;
}