export function showTransactionList(histories) {
    var html = '';

    var html = `
        <h3 class="mt-2 mb-2 text-center text-primary fw-bold">Transaction history</h3>
        <div style="overflow-x:auto;">
        <table cellpadding="10" cellspacing="10" border="0" style="border-collapse: collapse; margin: auto">
            <tr class="header">
                <td></td>
                <td>Type</td>
                <td>Remitter</td>
                <td>Amount</td>
                <td>Time</td>
                <td>Status</td>
            </tr>

    `

    for (let i = 0; i < histories.length; i++) {
        html += `<tr class="item">
                    <td><img src="${histories[i].icon}"></td>
                    <td>
                        ${histories[i].transaction}
                    </td>
                    <td>${histories[i].username}</td>
                    <td>
                        ${new Intl.NumberFormat().format(histories[i].amount)} VND
                    </td>
                    <td>
                        ${histories[i].time}
                    </td>
                    <td>
                        <span class="badge rounded-pill bg-warning">${histories[i].status}</span>
                    </td>
                    <td>
                        <a class="admin-action-for-transaction agree" data-id="${histories[i].stt}" data-actionType="agree">Agree</a> |
                        <a class="admin-action-for-transaction disagree" data-id="${histories[i].stt}" data-actionType="disagree">Disagree</a></td>
                    <td>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#${histories[i].ID}">More</button>
                    </td>
                </tr>`;
    }

    return html + `
    <div class="modal fade" id="agreeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirm</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Do you really want to unlock this account?      
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary btn-confirm-agree-transaction">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="disagreeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirm</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Do you really want to unlock this account?      
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary btn-confirm-disagree-transaction">Confirm</button>
                </div>
            </div>
        </div>
    </div>
    `;
}