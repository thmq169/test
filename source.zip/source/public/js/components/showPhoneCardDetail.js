export function showPhoneCardDetail(carrier, domination, amount, cardArr) {
    var html = '';
    console.log(cardArr)
    domination = new Intl.NumberFormat().format(domination) + ' VND';
    for (let i = 0; i < amount; i++) {
        html += `<tr class='item'>
                                <td>${carrier}</td>
                                <td>${domination}</td>
                                <td>${cardArr[i]}</td>
                            </tr>`
    }

    return `
        <h3 class="mt-2 mb-2 text-center text-primary">Detail</h3>
        <div class="border p-3 rounded">
            <table cellpadding='10' cellspacing='10' border='0'
                    style='border-collapse: collapse; margin: auto'>
                <tr class='header'>
                    <td>Carrier</td>
                    <td>Domination</td>
                    <td>Phone card</td>
                </tr>`

                +
                html
                +
                `
            </table>
                <button id="backTo_buyPhoneCard_form" class="btn btn-primary">Back</button>
        </div>
       
    `
}