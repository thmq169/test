export function withdraw() {
    return `
        <h3 class="mt-2 mb-2 text-center text-primary fw-bold">Withdraw</h3>
        <form novalidate id="withdraw_form" class="border p-3 rounded">
            <div class="row">
                <div class="col-lg-6 mb-lg-0">
                    <div class="form-group">
                    <label for="card">Card number</label>
                        <input type="number" class="form-control" id="card" placeholder="Card number"
                            name="card">
                    </div>
                </div>
                <div class="col-lg-6 mb-lg-0"> 
                    <div class="form-group">
                        <label for="exp">Card expiration</label>
                        <input type="date" class="form-control" id="exp" placeholder="Expiration"
                            name="exp">
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-lg-6 mb-lg-0">
                    <div class="form-group">
                        <label for="cvv">CVV</label>
                        <input type="number" class="form-control" id="cvv" placeholder="CVV" name="cvv">
                    </div>
                </div>
                <div class="col-lg-6 mb-lg-0"> 
                    <div class="form-group">
                        <label for="amount">Amount of money</label>
                        <input type="number" class="form-control" id="money" placeholder="Amount of money" name="amount">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="note">Note</label>
                <textarea class="form-control" id="note" placeholder="Note" name="note"></textarea>
            </div>

            <div class="form-group">
                <button id="submit_withdraw_form" class="btn btn-bg-cl-secondary" style="width: 100%">Withdraw</button>
            </div>
        </form>
    `
}