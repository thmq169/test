import { deposit } from "./components/deposit.js";
import { withdraw } from "./components/withdraw.js"
import { transfer } from "./components/transfer.js"
import { buyPhoneCard } from "./components/buyPhoneCard.js"
import { FlashMessage } from "./components/flashMessage.js"
import { showPhoneCardDetail } from "./components/showPhoneCardDetail.js"
import { showHistory } from "./components/showHistory.js"
import { showHistoryDetail } from "./components/showHistoryDetail.js"
import { showUserProfile } from "./components/showUserProfile.js"
import { showAbout } from "./components/showAbout.js"
import { showTransactionList } from "./components/showTransactionList.js"
import { showUserInfo } from "./components/showUserInfo.js"

setOnClick_resetPasswordForm_Btn()

const state = {
    actionType: 'about',
    userActivate: {},
    actionInfo: {
        stt: '',
        actionType: ''
    }
}

getUserActivate(state)

const actionFormArea = document.querySelector('#actionFormArea')

displayAction(state)
actionFormArea.innerHTML = showAbout()

document.onclick = async (e) => {
    if (e.target.className.includes('is-a-action')) {
        if (state.userActivate.userActivate || !e.target.className.includes('for-activate')) {
            state.actionType = e.target.id
            displayAction(state)
        }
    }

    if (e.target.className.includes('list-group-item function_menu')) {
        console.log('hello')
        if (state.userActivate.userActivate || !e.target.className.includes('for-activate')) {
            showActionForm(e.target.id)
        } else {
            createAlter(state.userActivate.message)
            console.log(state.userActivate.message)
        }
    }

    if (e.target.id === 'user_profile') {
        const actionFormArea = document.querySelector('#actionFormArea')
        const res = await FetchAPI_getProfile()
        console.log(res)
        actionFormArea.innerHTML = showUserProfile(res)
    }

    if (e.target.className === 'li-dropdown-action admin-action-for-waiting') {
        console.log('waiting action')
        var stt = e.target.getAttribute('data-id');
        var actionType = e.target.getAttribute('data-actionType');
        setOnClick_adminAction(stt, actionType)
        setOnClick_waitingList()
    }

    if (e.target.className === 'btn btn-success admin-action-for-locked') {
        console.log('unlock action')
        state.actionInfo.stt = e.target.getAttribute('data-id');
        state.actionInfo.actionType = e.target.getAttribute('data-actionType');

        var myModal = new bootstrap.Modal(document.getElementById('unlockModal'), {
            keyboard: false
        })
        myModal.show()
    }

    if (e.target.className === 'btn btn-primary btn-confirm-unlock-acc') {
        setOnClick_adminAction(state.actionInfo.stt, state.actionInfo.actionType)
        const my_modal = document.querySelector('#unlockModal');
        const modal = bootstrap.Modal.getInstance(my_modal);
        modal.hide(); 
        setOnClick_lockedList()  
    }

    if (e.target.className === 'admin-action-for-transaction agree') {
        e.preventDefault()
        console.log('action transaction')
        state.actionInfo.stt = e.target.getAttribute('data-id');
        state.actionInfo.actionType = e.target.getAttribute('data-actionType');
        
        var myModal = new bootstrap.Modal(document.getElementById('agreeModal'), {
            keyboard: false
        })
        myModal.show()
    }

    if (e.target.className === 'btn btn-primary btn-confirm-agree-transaction') {
        await setOnClick_adminAction(state.actionInfo.stt, state.actionInfo.actionType)
        const my_modal = document.querySelector('#agreeModal');
        const modal = bootstrap.Modal.getInstance(my_modal);
        modal.hide();
        await setOnClick_transactionList()
    }

    if (e.target.className === 'admin-action-for-transaction disagree') {
        e.preventDefault()
        console.log('action transaction')
        state.actionInfo.stt = e.target.getAttribute('data-id');
        state.actionInfo.actionType = e.target.getAttribute('data-actionType');
        console.log(e.target.getAttribute('data-id'), e.target.getAttribute('data-actionType'));

        var myModal = new bootstrap.Modal(document.getElementById('disagreeModal'), {
            keyboard: false
        })
        myModal.show()
    }

    if (e.target.className === 'btn btn-primary btn-confirm-disagree-transaction') {
        await setOnClick_adminAction(state.actionInfo.stt, state.actionInfo.actionType)
        const my_modal = document.querySelector('#disagreeModal');
        const modal = bootstrap.Modal.getInstance(my_modal);
        modal.hide();
        await setOnClick_transactionList()
    }

}

async function getUserActivate() {
    state.userActivate = await FetchAPI_getActiveInfo()
}

function displayAction(state) {
    const currentAction = document.getElementById(state.actionType)
    const actionList = document.getElementsByClassName('is-a-action')
    for (let index = 0; index < actionList.length; index++) {
        const element = actionList[index];
        if (element.className.includes('show-action')) {
            element.className = element.className.replace('show-action', '')
        }
    }
    currentAction.className += ' show-action'
}

function showActionForm(id) {
    switch (id) {
        case 'about':
            actionFormArea.innerHTML = showAbout()
            break
        case 'deposit':
            console.log('deposit')
            actionFormArea.innerHTML = deposit()
            setOnClick_depositForm_Btn()
            break

        case 'withdraw':
            console.log('withdraw')
            actionFormArea.innerHTML = withdraw()
            setOnClick_withdrawForm_Btn()
            break

        case 'transfer':
            console.log('transfer')
            actionFormArea.innerHTML = transfer(document.getElementById('user_fullname').innerHTML)

            document.getElementById('recipient_phone_number').onblur = async function () {
                const transfer_form = document.querySelector('#transfer_form').elements
                const phone = transfer_form[0].value
                const res = await FetchAPI_getRecipientName(phone)
                if (res.exist) {
                    document.getElementById('recipient_name_area').innerHTML = `
                    <label for='number'>Recipient</label>
                    <input type='text' class='form-control' id="recipient_name" name='receipient' value='` + res.recipientName + `' readonly>
                `
                } else {
                    document.getElementById('recipient_name_area').innerHTML = `
                    <label for='number'>Recipient</label>
                    <input type='text' class='form-control' id="recipient_name" name='receipient' value='unknown' readonly>
                    `
                }

            }
            setOnClick_transferForm_Btn()

            break;

        case 'buyphonecard':
            console.log('buyphonecard')
            actionFormArea.innerHTML = buyPhoneCard()
            setOnClick_buyPhoneCardForm_Btn()
            break;

        case 'history':
            console.log('history')
            setOnClick_history()
            break;

        case 'transactionList':
            console.log('transactionList')
            setOnClick_transactionList()
            break;

        case 'waitingList':
            console.log('waitingList')
            setOnClick_waitingList()
            break;

        case 'activatedList':
            console.log('activatedList')
            setOnClick_activatedList()
            break;

        case 'disabledList':
            console.log('disabledList')
            setOnClick_disabledList()
            break;

        case 'lockedList':
            console.log('lockedList')
            setOnClick_lockedList()
            break;

        default:
            break;
    }
}

function setOnClick_depositForm_Btn() {
    document.querySelector('#submit_deposit_form').onclick = async function (e) {
        e.preventDefault()
        const deposit_form = document.querySelector('#deposit_form').elements

        const cardNumber = deposit_form[0].value
        const expiration = deposit_form[1].value
        const cvv = deposit_form[2].value
        const amountMoney = deposit_form[3].value

        const res = await FetchAPI_deposit(cardNumber, expiration, cvv, amountMoney)

        if (res.isSuccess) {
            let newBalance = res.newBalance
            newBalance = new Intl.NumberFormat().format(newBalance) + ' VND';
            document.querySelector('#balanceArea').innerHTML = 'Balance: ' + newBalance
            deposit_form[0].value = ''
            deposit_form[1].value = ''
            deposit_form[2].value = ''
            deposit_form[3].value = ''
        }
        createAlter(res.message)
    }
}

function setOnClick_withdrawForm_Btn() {
    document.querySelector('#submit_withdraw_form').onclick = async function (e) {
        e.preventDefault()
        const withdraw_form = document.querySelector('#withdraw_form').elements

        const cardNumber = withdraw_form[0].value
        const expiration = withdraw_form[1].value
        const cvv = withdraw_form[2].value
        const amountMoney = withdraw_form[3].value
        const note = withdraw_form[4].value

        const res = await FetchAPI_withdraw(cardNumber, expiration, cvv, amountMoney, note)

        if (res.isSuccess) {
            let newBalance = res.newBalance
            newBalance = new Intl.NumberFormat().format(newBalance) + ' VND';
            document.querySelector('#balanceArea').innerHTML = 'Balance: ' + newBalance
            withdraw_form[0].value = ''
            withdraw_form[1].value = ''
            withdraw_form[2].value = ''
            withdraw_form[3].value = ''
            withdraw_form[4].value = ''
        }
        createAlter(res.message)
    }
}

function setOnClick_transferForm_Btn() {
    document.querySelector('#submit_transfer_form').onclick = async function (e) {
        e.preventDefault()

        const transfer_form = document.querySelector('#transfer_form').elements

        const crpPhone = transfer_form[0].value
        const receipient = transfer_form[1].value
        const amount = transfer_form[2].value
        const note = transfer_form[3].value
        const feeByYou = transfer_form[4].checked
        const feeByReceipient = transfer_form[5].checked
        let bearer = 'you'
        if (feeByReceipient) {
            bearer = 'recipient'
        }
        const sendfor = 'entersubmit'

        document.querySelector('#submit_transfer_form').innerHTML = `<div class="spinner-border" role="status"></div>`
        document.querySelector('#submit_transfer_form').disabled = true

        const res = await FetchAPI_transfer(crpPhone, amount, note, bearer, sendfor, null)
        
        document.querySelector('#submit_transfer_form').innerHTML = `Transfer`
        document.querySelector('#submit_transfer_form').disabled = false

        if (res.success) {
            var myModal = new bootstrap.Modal(document.getElementById('transferModal'), {
                keyboard: false
            })
            myModal.show()
        }
        
        createAlter(res.message)
    }

    document.querySelector('#enter_otp_btn').onclick = async function (e) {
        e.preventDefault()
        const otp = document.getElementById('otp').value
        const sendfor = 'enterotp'
        console.log(otp)
        const res = await FetchAPI_transfer(null, null, null, null, sendfor, otp)
        console.log(res)
        if (res.isSuccess) {
            transfer_form[0].value = ''
            transfer_form[1].value = ''
            transfer_form[2].value = ''
            transfer_form[3].value = document.getElementById('user_fullname').innerHTML + ' transfer'
            transfer_form[4].checked = true
            transfer_form[5].checked = false

            hideModal()

            document.getElementById('recipient_name_area').innerHTML = ''
            document.getElementById('otp').value = ''

            let currentBalance = res.currentBalance
            currentBalance = new Intl.NumberFormat().format(currentBalance) + ' VND';
            document.querySelector('#balanceArea').innerHTML = 'Balance: ' + currentBalance
        }

        createAlter(res.message)
    }

    function hideModal() {
        const my_modal = document.querySelector('#transferModal');
        const modal = bootstrap.Modal.getInstance(my_modal);
        modal.hide();
    }

    document.querySelector('#reset_otp_btn').onclick = async function (e) {
        e.preventDefault()

        document.querySelector('#reset_otp_btn').innerHTML = `<div class="spinner-border" role="status"></div>`
        document.querySelector('#reset_otp_btn').disabled = true

        const sendfor = 'sendagain'
        console.log('enterotp')
        const res = await FetchAPI_transfer(null, null, null, null, sendfor, null)
        
        document.querySelector('#reset_otp_btn').innerHTML = `Send again`
        document.querySelector('#reset_otp_btn').disabled = false
        
        createAlter(res.message)
    }
}

function setOnClick_buyPhoneCardForm_Btn() {
    document.querySelector('#submit_buyPhoneCard_form').onclick = async function (e) {
        e.preventDefault()
        const carrier = document.querySelector('input[name="carrier"]:checked').value
        const domination = document.querySelector('input[name="domination"]:checked').value;
        const amount = document.querySelector('input[name="amount"]').value;

        const res = await FetchAPI_byPhoneCard(carrier, domination, amount)

        if (res.isSuccess) {
            document.querySelector('input[name="carrier"]:checked').checked = false
            document.querySelector('input[name="domination"]:checked').checked = false
            document.querySelector('input[name="amount"]').value = ''

            let currentBalance = res.currentBalance
            currentBalance = new Intl.NumberFormat().format(currentBalance) + ' VND';
            document.querySelector('#balanceArea').innerHTML = 'Balance: ' + currentBalance

            actionFormArea.innerHTML = showPhoneCardDetail(carrier, domination, amount, res.cardArr)
            document.querySelector('#backTo_buyPhoneCard_form').onclick = function () {
                actionFormArea.innerHTML = buyPhoneCard()
            }
        }

        createAlter(res.message)
    }
}

async function setOnClick_history() {
    const res = await FetchAPI_getHistory()
    actionFormArea.innerHTML = showHistory(res.historyData)
    document.getElementById('modal_history_detail').innerHTML = showHistoryDetail(res.historyData, res.detailData)
    console.log(res)
}

function setOnClick_resetPasswordForm_Btn() {
    const btn_reset_password_form = document.querySelector('#submit_reset_password_form')
    if (!btn_reset_password_form) {
        return null;
    }
    var emailUser = null;
    btn_reset_password_form.onclick = async function (e) {
        e.preventDefault()

        const transfer_form = document.querySelector('#reset_password_form').elements

        const email = transfer_form[0].value
        emailUser = email
        const phone = transfer_form[1].value
        const sendFor = 'entersubmit'

        console.log(sendFor, email)

        btn_reset_password_form.innerHTML = `<div class="spinner-border" role="status"></div>`
        btn_reset_password_form.disabled = true

        const res = await FetchAPI_resetPassword(email, phone, sendFor, null)

        btn_reset_password_form.innerHTML = `Submit`
        btn_reset_password_form.disabled = false
        console.log(res)
        if (!res.error) {
            var myModal = new bootstrap.Modal(document.getElementById('myResetModal'), {
                keyboard: false
            })
            myModal.show()
        }

        createAlter(res.message)
    }

    document.querySelector('#enter_otp_btn').onclick = async function (e) {
        e.preventDefault()
        const otp = document.getElementById('otp').value
        const sendfor = 'enterotp'

        const res = await FetchAPI_resetPassword(null, null, sendfor, otp)

        console.log(res)
        if (res.isSuccess) {
            location.href = ('http://localhost:3000/resetpassword')
        }
        createAlter(res.message)
    }

    document.querySelector('#reset_otp_btn').onclick = async function (e) {
        e.preventDefault()

        document.querySelector('#reset_otp_btn').innerHTML = `<div class="spinner-border" role="status"></div>`
        document.querySelector('#reset_otp_btn').disabled = true

        const sendfor = 'sendagain'
        const res = await FetchAPI_resetPassword(emailUser, null, sendfor, null)

        document.querySelector('#reset_otp_btn').innerHTML = `Send again`
        document.querySelector('#reset_otp_btn').disabled = false

        createAlter(res.message)
    }
}

async function setOnClick_transactionList() {
    const res = await FetchAPI_transactionList()
    console.log(res)
    actionFormArea.innerHTML = showTransactionList(res.historyData)
    document.getElementById('modal_history_detail').innerHTML = showHistoryDetail(res.historyData, res.detailData)
}

async function setOnClick_waitingList() {
    const res = await FetchAPI_getWaitingAcc()
    console.log(res)
    actionFormArea.innerHTML = showUserInfo(res.userData, 'User are waiting', 'waitingList')
}

async function setOnClick_activatedList() {
    const res = await FetchAPI_getActivatedAcc()
    console.log(res)
    actionFormArea.innerHTML = showUserInfo(res.userData, 'User was activated', 'activatedList')
}

async function setOnClick_disabledList() {
    const res = await FetchAPI_getDisableAcc()
    console.log(res)
    actionFormArea.innerHTML = showUserInfo(res.userData, 'User was disabled', 'disabledList')
}

async function setOnClick_lockedList() {
    const res = await FetchAPI_getLockedAcc()
    console.log(res)
    actionFormArea.innerHTML = showUserInfo(res.userData, 'User was locked', 'lockedList')
}

async function setOnClick_adminAction(stt, actionType) {
    const res = await FetchAPI_postAdminAction(stt, actionType)
    console.log(res)
    createAlter(res.message)
}

async function FetchAPI_getActiveInfo() {
    return fetch('http://localhost:3000/getActiveInfo', {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then(data => {
            return data.result
        })
}

async function FetchAPI_deposit(card, exp, cvv, amount, note) {
    const data = { card, exp, cvv, amount, note }

    return fetch('http://localhost:3000/deposit', {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(res => res.json())
        .then(data => {
            return data.result
        })
}

async function FetchAPI_withdraw(card, exp, cvv, amount, note) {
    const data = { card, exp, cvv, amount, note }

    return fetch('http://localhost:3000/withdraw', {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(res => res.json())
        .then(data => {
            return data.result
        })
}

async function FetchAPI_getRecipientName(phone) {
    const data = { phone }
    return fetch('http://localhost:3000/getRecipientName', {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(res => res.json())
        .then(data => {
            return data.result
        })
}

async function FetchAPI_transfer(rcpPhone, amount, note, bearer, sendfor, otp) {
    const data = { rcpPhone, amount, note, bearer, sendfor, otp }
    return fetch('http://localhost:3000/transfer', {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(res => res.json())
        .then(data => {
            return data.result
        })
}

async function FetchAPI_byPhoneCard(carrier, domination, amount) {
    const data = { carrier, domination, amount }
    return fetch('http://localhost:3000/buyphonecard', {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(res => res.json())
        .then(data => {
            return data.result
        })
}

async function FetchAPI_getHistory() {
    return fetch('http://localhost:3000/history', {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then(data => {
            return data
        })
}

async function FetchAPI_getProfile() {
    return fetch('http://localhost:3000/profile', {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then(data => {
            return data
        })
}

async function FetchAPI_resetPassword(email, phone, sendFor, otp) {
    const data = { email, phone, sendFor, otp }
    return fetch('http://localhost:3000/formresetpass', {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(res => res.json())
        .then(data => {
            return data.result
        })
}

async function FetchAPI_transactionList() {
    return fetch('http://localhost:3000/transactionlist', {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then(data => {
            return data
        })
}

async function FetchAPI_getWaitingAcc() {
    return fetch('http://localhost:3000/waitinglist', {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then(data => {
            return data.userData
        })
}

async function FetchAPI_getActivatedAcc() {
    return fetch('http://localhost:3000/activatedlist', {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then(data => {
            return data.userData
        })
}

async function FetchAPI_getDisableAcc() {
    return fetch('http://localhost:3000/disabledlist', {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then(data => {
            return data.userData
        })
}

async function FetchAPI_getLockedAcc() {
    return fetch('http://localhost:3000/lockedlist', {
        method: 'GET',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then(data => {
            return data.userData
        })
}

async function FetchAPI_postAdminAction(stt, actionType) {
    const data = { stt, actionType }
    return fetch('http://localhost:3000/adminaction', {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(res => res.json())
        .then(data => {
            return data.result
        })
}

function createAlter(message) {
    document.getElementById('alertArea').innerHTML = FlashMessage(message)
    console.log('create alterrr')
    setTimeout(() => {
        if (document.querySelector('#myAlert')) {
            var alertNode = document.querySelector('#myAlert')
            alertNode.remove()
        }
    }, 2500);
}

