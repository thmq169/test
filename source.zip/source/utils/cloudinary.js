const cloudinary = require('cloudinary')

cloudinary.config({
    cloud_name: 'dffgj00gs',
    api_key: '925146233177285',
    api_secret: 'TwPHY9tZ2529UOyI8ZQRNGNvgIU'
});

exports.uploads = (file, folder) => {
    return new Promise(resolve => {
        cloudinary.uploader.upload(file, (result) => {
            resolve({
                url: result.url,
                id: result.public_id
            })
        }, {
            resource_type: "auto",
            folder: folder
        })
    })
}