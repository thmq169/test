const path = require('path');
const fs = require('fs');
const express = require('express');
const configViewEngine = require('./config/viewengine');
const route = require('./routes');
const conn = require('./config/db');

const app = express();
configViewEngine(app);

app.use(express.static(__dirname + '/public'));

app.use(express.json());
app.use(express.urlencoded({
	extended: true
}));
app.use(require('express-session')({secret: 'abs'}));

conn.connect(function (err) {
	if (!err) {
		console.log('Connected');
	}
	else {
		console.log('Error');
	}
})

route(app);

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
	console.log(`http://localhost:${PORT}`)
});

