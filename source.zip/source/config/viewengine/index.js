const path = require('path');
const expressHandlebars = require('express-handlebars');

function configViewEngine(app) {
    app.engine('handlebars', expressHandlebars.engine({
        defaultLayout: 'main',
        helpers: {
            waitingList: function (users) {
                var html = '';

                for (let i = 0; i < users.length; i++) {
                    html += `<tr class="item">
                                <td>
                                    <img src="data:image;base64,'.base64_encode(${users[i].frontIC}).'"alt="Image" style="width:100px; height:100px;" >
                                </td>
                                <td>
                                    <img src="data:image;base64,'.base64_encode(${users[i].backIC}).'"alt="Image" style="width:100px; height:100px;" >
                                </td>
                                <td>
                                    ${users[i].fullname}
                                </td>                      
                                <td>
                                    ${users[i].email}
                                </td>
                                <td>
                                    ${users[i].phone}
                                </td>
                                <td>
                                    ${users[i].birthday.toLocaleDateString('vi-VN')}
                                </td>
                                <td>
                                    ${users[i].address}
                                </td>
                                <td><a onclick="return action()" href="adminaction/${users[i].stt}&verify">Verify</a> | <a
                                    onclick="return action()" href="adminaction/${users[i].stt}&cancel">Cancel</a> | <a
                                    onclick="return action()" href="adminaction/${users[i].stt}&request">Request</a></td>
                            </tr>`;
                }

                return html;
            },

            activatedList: function (users) {
                var html = '';

                for (let i = 0; i < users.length; i++) {
                    if (users[i].username == 'admin') {
                        continue;
                    }
                    html += `<tr class="item">
                                <td>
                                    <img src="data:image;base64,'.base64_encode(${users[i].frontIC}).'"alt="Image" style="width:100px; height:100px;" >
                                </td>
                                <td>
                                    <img src="data:image;base64,'.base64_encode(${users[i].backIC}).'"alt="Image" style="width:100px; height:100px;" >
                                </td>
                                <td>
                                    ${users[i].fullname}
                                </td>                      
                                <td>
                                    ${users[i].email}
                                </td>
                                <td>
                                    ${users[i].phone}
                                </td>
                                <td>
                                    ${users[i].birthday.toLocaleDateString('vi-VN')}
                                </td>
                                <td>
                                    ${users[i].address}
                                </td>
                                <td>
                                    <button type="button" class="btn btn-link" data-toggle="modal" data-target="#a${users[i].stt}">Details</button>
                                </td>
                            </tr>`;
                }

                return html;
            },

            disabledList: function (users) {
                var html = '';

                for (let i = 0; i < users.length; i++) {
                    html += `<tr class="item">
                                <td>
                                    <img src="data:image;base64,'.base64_encode(${users[i].frontIC}).'"alt="Image" style="width:100px; height:100px;" >
                                </td>
                                <td>
                                    <img src="data:image;base64,'.base64_encode(${users[i].backIC}).'"alt="Image" style="width:100px; height:100px;" >
                                </td>
                                <td>
                                    ${users[i].fullname}
                                </td>                      
                                <td>
                                    ${users[i].email}
                                </td>
                                <td>
                                    ${users[i].phone}
                                </td>
                                <td>
                                    ${users[i].birthday.toLocaleDateString('vi-VN')}
                                </td>
                                <td>
                                    ${users[i].address}
                                </td>
                            </tr>`;
                }
                return html;
            },

            lockedList: function (users) {
                var html = '';

                for (let i = 0; i < users.length; i++) {
                    if (users[i].username == 'admin') {
                        continue;
                    }
                    html += `<tr class="item">
                                <td>
                                    <img src="data:image;base64,'.base64_encode(${users[i].frontIC}).'"alt="Image" style="width:100px; height:100px;" >
                                </td>
                                <td>
                                    <img src="data:image;base64,'.base64_encode(${users[i].backIC}).'"alt="Image" style="width:100px; height:100px;" >
                                </td>
                                <td>
                                    ${users[i].fullname}
                                </td>                      
                                <td>
                                    ${users[i].email}
                                </td>
                                <td>
                                    ${users[i].phone}
                                </td>
                                <td>
                                    ${users[i].birthday.toLocaleDateString('vi-VN')}
                                </td>
                                <td>
                                    ${users[i].address}
                                </td>
                                <td><a onclick="return action()" href="adminaction/${users[i].stt}&unlock">Unlock</a></td>
                            </tr>`;
                }

                return html;
            },
        }
    }));
    app.set('view engine', 'handlebars');
    app.set('views', path.join(__dirname, '../../views'));
}

module.exports = configViewEngine;