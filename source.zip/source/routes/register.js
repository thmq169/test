const express = require('express');
const router = express.Router();

const registerController = require('../controllers/RegisterController');

const upload = require('../config/multer.js')

router.get('/', registerController.get);
router.post('/', upload.fields([{name: 'frontIC', maxCount: 1}, {name: 'backIC', maxCount: 1}]), registerController.post)

module.exports = router;