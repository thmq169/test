const express = require('express');
const router = express.Router();

const profileController = require('../controllers/ProfileController');

const upload = require('../config/multer.js')

router.post('/changepass', profileController.postChangepass);
router.get('/changepass', profileController.getChangepass);
router.get('/reupIC', profileController.getReupIC);
router.post('/reupIC', upload.fields([{name: 'frontIC', maxCount: 1}, {name: 'backIC', maxCount: 1}]), profileController.postReupIC);
router.get('/', profileController.get);

module.exports = router;