const express = require('express');
const router = express.Router();

const homeController = require('../controllers/HomeController');
const featureController = require('../controllers/FeatureController');

router.post('/adminaction', homeController.getAdminaction);

router.get('/transactionlist', featureController.getTransactionlist);

router.get('/lockedlist', featureController.getLockedlist);

router.get('/disabledlist', featureController.getDisabledlist);

router.get('/activatedlist', featureController.getActivatedlist);

router.get('/waitinglist', featureController.getWaitinglist);

router.get('/history', featureController.getHistory);

router.post('/buyphonecard', featureController.postBuyphonecard);

router.post('/transfer', featureController.postTransfer);
router.post('/getRecipientName', featureController.postRecipientName);

router.post('/withdraw', featureController.postWithdraw);

router.post('/deposit', featureController.postDeposit);

router.get('/getActiveInfo', featureController.getActiveInfo);

router.get('/formresetpass', homeController.getFormresetpass);
router.post('/formresetpass', homeController.postFormresetpass);

router.get('/resetpassword', homeController.getResetpassword);
router.post('/resetpassword', homeController.postResetpassword);

router.get('/logout', homeController.logout);

router.post('/changepassfirst', homeController.postChangepassfirst);
router.get('/changepassfirst', homeController.getChangepassfirst);

router.get('/', homeController.index);

module.exports = router;