const conn = require('../config/db');

const Money = function (money) {
    this.username = money.username;
    this.balance = money.balance;
    this.time = money.time;
    this.date = money.date;
    this.otp = money.otp;
    this.otptime = money.otptime;
}

Money.insert = function (param) {
    return new Promise((resolve, reject) => {
        conn.query(`insert into money SET ?`, param, (err) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: 'create new money failed'
                });
            }
            resolve({
                status: 'success',
                message: 'create new money successfully'
            });
        })
    })    
}

Money.get = function (column, param) {
    const sql = `select * from money where ${column} = '${param}'`;

    return new Promise( (resolve, reject) => {
        conn.query(sql, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    hasError: true,
                });
            }

            if (res.length) {
                
                resolve({
                    userData: res[0],
                    hasError: false,
                });
            } 
        })
    }) 
}

Money.update = function(updateColumn, updateParam, column, param) {
    const sql =`update money set ${updateColumn} = ${updateParam} where ${column} = '${param}'`

    return new Promise((resolve, reject) => {
        conn.query(sql, (err) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: 'update money failed'
                });
            }
            resolve({
                status: 'success',
                message: 'update money successfully'
            });
        })
    }) 
}

module.exports = Money;
