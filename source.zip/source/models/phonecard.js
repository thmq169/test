const conn = require('../config/db');

const Phonecard = function (phonecard) {
    this.carrier = phonecard.carrier;
    this.code = phonecard.code;
}

Phonecard.get = function(column, param) {
    const sql = `select * from phonecard where ${column} = '${param}'`;

    return new Promise( (resolve, reject) => {
        conn.query(sql, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    hasError: true,
                });
            }

            if (res.length) {
                resolve({
                    phoneCardData: res[0],
                    hasError: false,
                });
            } 
        })
    }) 
}

module.exports = Phonecard;