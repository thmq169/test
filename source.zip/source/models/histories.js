const conn = require('../config/db');

const Histories = function (histories) {
    this.ID = histories.ID;
    this.username = histories.username;
    this.icon = histories.icon;
    this.transaction = histories.transaction;
    this.amount = histories.amount;
    this.time = histories.time;
    this.status = histories.status;
}

Histories.get = function(column, param) {
    const sql = `select * from histories where ${column} = '${param}' ORDER BY time DESC`

    return new Promise((resolve, reject) => {
        conn.query(sql, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: '505 error'
                });
            }
            console.log(res)
            resolve({
                status: 'success',
                historyData: res
            });
        })
    })
}

Histories.getTotal = function(column, param) {
    return new Promise((resolve, reject) => {
        conn.query(`select * from histories where ${column} = '${param}'`, (err, res) => {
            if (err) {
                resolve({
                    hasError: true
                })
            }

            resolve({
                hasError: false,
                total: res.length
            })
        })
    })
    
}

Histories.insert = function (param, callback) {
    return new Promise((resolve, reject) => {
        conn.query(`insert into histories SET ?`, param, (err) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: 'create new transaction failed'
                });
            }
            resolve({
                status: 'success',
                message: 'create new transaction successfully'
            });
        })
    })    
}

Histories.getAll = function() {
    return new Promise((resolve, reject) => {
        conn.query(`select * from histories`, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: '505 error'
                });
            }
            console.log(res)
            resolve({
                status: 'success',
                historyData: res
            });
        })
    })
   
}

Histories.gets = function(column, param, callback) {
    conn.query(`select * from histories where ${column} = '${param}'`, (err, res) => {
        return callback(null, res);
    })
}

Histories.update = function(updateColumn, updateParam, column, param) {
    const sql = `update histories set ${updateColumn} = '${updateParam}' where ${column} = '${param}'`

    return new Promise((resolve, reject) => {
        conn.query(sql, (err) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: 'update History failed'
                });
            }
            resolve({
                status: 'success',
                message: 'update History successfully'
            });
        })
    })
}

module.exports = Histories;