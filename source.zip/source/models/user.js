const conn = require('../config/db');

const User = function (user) {
    this.stt = user.stt;
    this.fullname = user.fullname;
    this.email = user.email;
    this.phone = user.phone;
    this.birthday = user.birthday;
    this.address = user.address;
    this.username = user.username;
    this.password = user.password;
    this.checkfirst = user.checkfirst;
    this.activate = user.activate;
    this.block = user.block;
    this.frontIC = user.frontIC;
    this.backIC = user.backIC;
    this.dateCreate = user.dateCreate;
    this.dateUpdate = user.dateUpdate;
}

User.insert = function (param) {
    return new Promise((resolve, reject) => {
        conn.query(`insert into users SET ?`, param, (err) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: 'create new user failed'
                });
            }
            resolve({
                status: 'success',
                message: 'create new user successfully'
            });
        })
    })
}

User.find = function (column, param) {

    const sql = `select * from users where ${column} = '${param}'`;
    return new Promise((resolve, reject) => {
        conn.query(sql, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    hasError: true,
                    exist: null
                });
            }

            if (res.length) {
                resolve({
                    userData: res[0],
                    hasError: false,
                    exist: true
                });
            }

            resolve({
                hasError: false,
                exist: false
            });
        })
    })
}

User.get = function (column, param) {
    const sql = `select * from users where ${column} = '${param}'`;

    return new Promise((resolve, reject) => {
        conn.query(sql, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    hasError: true,
                });
            }

            if (res.length) {
                resolve({
                    userData: res[0],
                    hasError: false,
                });
            } else {
                resolve({
                    userData: null,
                    hasError: false,
                });
            }
        })
    })
}

User.update = function (updateColumn, updateParam, column, param) {
    const sql = `update users set ${updateColumn} = '${updateParam}' where ${column} = '${param}'`

    return new Promise((resolve, reject) => {
        conn.query(sql, (err) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: 'update user failed'
                });
            }
            resolve({
                status: 'success',
                message: 'update user successfully'
            });
        })
    })

}

User.gets = function (column, param) {
    try {
        const sql = `select stt, fullname, email, phone, birthday, address, activate, block, frontIC, backIC from users where ${column} = '${param}' ORDER BY dateCreate DESC`;

        return new Promise((resolve, reject) => {
            conn.query(sql, (err, res) => {
                if (err) {
                    console.log(err)
                    resolve({
                        hasError: true,
                    });
                }

                if (res.length) {
                    resolve({
                        userData: res,
                        hasError: false,
                    });
                } else {
                    resolve({
                        userData: [],
                        hasError: false,
                    });
                }
            })
        })
    } catch (error) {
        console.log(error)
    }
}

User.queryForWaitingList = function () {
    try {
        const sql = `select stt, fullname, email, phone, birthday, address, activate, block, frontIC, backIC from users where activate= '0' or activate= '3' or activate= '4' ORDER BY dateUpdate DESC`;

        return new Promise((resolve, reject) => {
            conn.query(sql, (err, res) => {
                if (err) {
                    console.log(err)
                    resolve({
                        hasError: true,
                    });
                }

                if (res.length) {
                    resolve({
                        userData: res,
                        hasError: false,
                    });
                } else {
                    resolve({
                        userData: [],
                        hasError: false,
                    });
                }
            })
        })
    } catch (error) {
        console.log(error)
    }
}

User.queryForBlockList = function () {
    try {
        const sql = `select stt, fullname, email, phone, birthday, address, activate, block, frontIC, backIC from users where block=1 ORDER BY dateUpdate DESC`;

        return new Promise((resolve, reject) => {
            conn.query(sql, (err, res) => {
                if (err) {
                    console.log(err)
                    resolve({
                        hasError: true,
                    });
                }

                if (res.length) {
                    resolve({
                        userData: res,
                        hasError: false,
                    });
                } else {
                    resolve({
                        userData: [],
                        hasError: false,
                    });
                }
            })
        })
    } catch (error) {
        console.log(error)
    }

}

module.exports = User;