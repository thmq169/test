const conn = require('../config/db');

const Details = function (details) {
    this.ID = details.ID;
    this.username = details.username;
    this.carrier = details.carrier;
    this.domination = details.domination;
    this.code = details.code;
    this.time = details.time;
    this.recipphone = details.recipphone;
    this.recipname = details.recipname;
    this.bearer = details.bearer;
    this.note = details.note;
}

Details.insert = function (param, callback) {
    conn.query(`insert into details SET ?`, param, (err) => {
        if (err) {
            return callback(err);
        }
        return callback(null);
    })
}

Details.getAll = function() {
    return new Promise((resolve, reject) => {
        conn.query(`select * from details`, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: '505 error'
                });
            }
            console.log(res)
            resolve({
                status: 'success',
                detailData: res
            });
        })
    })
}

Details.get = function(column, param) {
    const sql = `select * from details where ${column} = '${param}'`;

    return new Promise( (resolve, reject) => {
        conn.query(sql, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    hasError: true,
                });
            }

            if (res.length) {
                resolve({
                    detailData: res[0],
                    hasError: false,
                });
            } 
        })
    }) 
}

module.exports = Details;
