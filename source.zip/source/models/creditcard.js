const conn = require('../config/db');

const Creditcard = function (creditcard) {
    this.cardnum = creditcard.cardnum;
    this.exp = creditcard.exp;
    this.cvv = creditcard.cvv;
}

Creditcard.find = function(column, param, callback) {
    const sql = `select * from creditcard where ${column} = '${param}'`

    return new Promise((resolve, reject) => {
        conn.query(sql, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    hasError: true,
                    exist: null
                });
            }

            if (res.length) {
                resolve({
                    userData: res[0],
                    hasError: false,
                    exist: true
                });
            } 

            resolve({
                hasError: false,
                exist: false
            });
        })
    })
}

Creditcard.get = function(column, param) {
    const sql = `select * from creditcard where ${column} = '${param}'`

    return new Promise((resolve, reject) => {
        conn.query(sql, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    hasError: true
                })
                
            }
            resolve({
                hasError: true,
                creditData: res[0]
            })
        })
    })
}

module.exports = Creditcard;
