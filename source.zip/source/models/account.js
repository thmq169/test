const conn = require('../config/db');

const Account = function (account) {
    this.username = account.username;
    this.wrongtimes = account.wrongtimes;
    this.anlg = account.anlg;
    this.time = account.time;
}

Account.insert = function (param, callback) {
    return new Promise((resolve, reject) => {
        conn.query(`insert into accounts SET ?`, param, (err) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: 'create new account failed'
                });
            }
            resolve({
                status: 'success',
                message: 'create new  successfully'
            });
        })
    })
}

Account.get = function(column, param) {
    const sql = `select * from accounts where ${column} = '${param}'`;

    return new Promise((resolve, reject) => {
        conn.query(sql, (err, res) => {
            if (err) {
                console.log(err)
                resolve({
                    hasError: true,
                });
            }

            if (res.length) {
                resolve({
                    accountData: res[0],
                    hasError: false,
                });
            } else {
                resolve({
                    accountData: [],
                    hasError: false,
                });
            }
        })
    })
}

Account.update = function(updateColumn, updateParam, column, param) {
    const sql = `update accounts set ${updateColumn} = ${updateParam} where ${column} = '${param}'`
    return new Promise((resolve, reject) => {
        conn.query(sql, (err) => {
            if (err) {
                console.log(err)
                resolve({
                    status: 'fail',
                    message: 'update account failed'
                });
            }
            resolve({
                status: 'success',
                message: 'update account successfully'
            });
        })
    })
}

module.exports = Account;